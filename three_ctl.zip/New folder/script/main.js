console.clear();
window.addEventListener('load', function() {
	if (!Detector.webgl) Detector.addGetWebGLMessage();

	var w = window.innerWidth,
		h = window.innerHeight / 2;

	var container, renderer, scene, camera, controls, children;
	var raycaster,
		mouse = new THREE.Vector2(),
		INTERSECTED,
		bbox;

	var container2,
		renderer2,
		cam2,
		controls2,
		camHelper,
		stats,
		isDown = false,
		isDragging = false;

	(function init() {
		// renderer
		renderer = new THREE.WebGLRenderer({
			antialias: true
		});
		renderer.setPixelRatio(window.devicePixelRatio);
		renderer.setSize(w, h);
		container = document.getElementById('container');
		container.appendChild(renderer.domElement);

		renderer2 = new THREE.WebGLRenderer({
			antialias: true
		});
		renderer2.setPixelRatio(window.devicePixelRatio);
		renderer2.setSize(w, h);
		container2 = document.getElementById('container2');
		container2.appendChild(renderer2.domElement);
		stats = new Stats();
		container2.appendChild(stats.dom);
		stats.dom.style.position = 'absolute';

		// world
		scene = new THREE.Scene();
		scene.fog = new THREE.FogExp2(0x1e2630, 0.002);
		renderer.setClearColor(scene.fog.color);
		renderer2.setClearColor(scene.fog.color);

		// camera
		camera = new THREE.PerspectiveCamera(60, w / h, 1, 2000);
		camera.position.x = 0;
		camera.position.y = 55;
		camera.position.z = 140;
		camera.lookAt(new THREE.Vector3(0, 0, 0));
		camHelper = new THREE.CameraHelper(camera);
		scene.add(camHelper);
		controls = new THREE.OrbitControls(camera, renderer.domElement);

		cam2 = new THREE.PerspectiveCamera(60, w / h, 1, 2000);
		cam2.position.x = 0;
		cam2.position.y = 100;
		cam2.position.z = 400;
		cam2.lookAt(new THREE.Vector3(0, 0, 0));
		controls2 = new THREE.OrbitControls(cam2, renderer2.domElement);

		// helpers
		var axes = new THREE.AxisHelper(50);
		// scene.add(axes);
		var gridXZ = new THREE.GridHelper(500, 10);
		scene.add(gridXZ);

		// lights
		light = new THREE.DirectionalLight(0xffffff);
		light.position.set(1, 1, 1);
		scene.add(light);
		light = new THREE.DirectionalLight(0x002288);
		light.position.set(-1, -1, -1);
		scene.add(light);
		light = new THREE.AmbientLight(0x222222);
		scene.add(light);

		children = new THREE.Object3D();

		var material = new THREE.MeshPhongMaterial({
			color: 0xfb3550,
			shading: THREE.FlatShading
		});
		// Dome
		geometry = new THREE.IcosahedronGeometry(700, 1);
		var domeMaterial = new THREE.MeshPhongMaterial({
			color: 0xfb3550,
			shading: THREE.FlatShading,
			side: THREE.BackSide
		});
		var dome = new THREE.Mesh(geometry, domeMaterial);
		scene.add(dome);

		//sphere
		geometry = new THREE.SphereGeometry(15, 100, 100);
		var sphere = new THREE.Mesh(geometry, material.clone());
		sphere.position.set(-60, 15, -50);
		// children.add(sphere);

		//cylinder
		geometry = new THREE.CylinderGeometry(0, 20, 40, 100);
		var cylinder = new THREE.Mesh(geometry, material.clone());
		cylinder.position.set(-90, 20, 30);
		// children.add(cylinder);

		//Dodecahedron
		geometry = new THREE.DodecahedronGeometry(20, 0);
		var dodecahedron = new THREE.Mesh(geometry, material.clone());
		dodecahedron.position.set(10, 20, -30);
		// children.add(dodecahedron);

		//heart
		// =========================
		const x = 0,
			y = 0;

		const heartShape = new THREE.Shape();

		heartShape.moveTo(x + 5, y + 5);
		heartShape.bezierCurveTo(x + 5, y + 5, x + 4, y, x, y);
		heartShape.bezierCurveTo(x - 6, y, x - 6, y + 7, x - 6, y + 7);
		heartShape.bezierCurveTo(x - 6, y + 11, x - 3, y + 15.4, x + 5, y + 19);
		heartShape.bezierCurveTo(x + 12, y + 15.4, x + 16, y + 11, x + 16, y + 7);
		heartShape.bezierCurveTo(x + 16, y + 7, x + 16, y, x + 10, y);
		heartShape.bezierCurveTo(x + 7, y, x + 5, y + 5, x + 5, y + 5);

		const geometryh = new THREE.ShapeGeometry(heartShape);
		const materialh = new THREE.MeshBasicMaterial({ color: 0xfb3550 });
		const mesh = new THREE.Mesh(geometryh, materialh);
		const mesh2 = new THREE.Mesh(geometryh, materialh);
		mesh.rotation.z += 3.15;
		mesh.translateX(-5.5);
		mesh.translateY(-70);

		mesh2.rotation.z += 3.15;
		mesh2.rotation.y += 3.15;
		mesh2.translateX(-5.5);
		mesh2.translateY(-70);

		heartOj = new THREE.Object3D();
		heartOj.add(mesh);
		heartOj.add(mesh2);

		children.add(heartOj);
		// scene.add(heartOj);

		// scene.add(mesh);
		// scene.add(mesh2);
		// =============================

		// logo dota
		// =============================

		// =============================

		// text
		// =============================
		var loader = new THREE.FontLoader();
		loader.load('../src/font/gentilis_bold.typeface.json', function(font) {
			let text = 'Panasonic';
			let myArr = text.split('');
			for (let i = 0; i < myArr.length; ++i) {
				let textGeometry = new THREE.TextGeometry(myArr[i], {
					font: font,

					size: 40,
					height: 10,
					curveSegments: 5,

					bevelThickness: 1,
					bevelSize: 1,
					bevelEnabled: true
				});

				let textMaterial = new THREE.MeshPhongMaterial({ color: 0x0056a8, specular: 0xffffff });

				let char = new THREE.Mesh(textGeometry, textMaterial);

				char.translateX(-120 + i * 30);

				children.add(char);
			}
		});
		// =============================

		// flag
		// =============================

		const [ width, height ] = [ 600, 400 ];
		let flag;
		let flagColor = '#ffffff';
		let flagTexture = null;
		const [ sizeW, sizeH, segW, segH ] = [ 30, 20, 30, 20 ];

		// =============================
		console.log(children.children);
		scene.add(children);

		raycaster = new THREE.Raycaster();
		var geometry = new THREE.BoxGeometry(1, 1, 1);
		var material = new THREE.MeshBasicMaterial({
			color: 0x00ff00
		});
		var cube = new THREE.Mesh(geometry, material);
		bbox = new THREE.BoxHelper(cube);
		scene.add(bbox);

		window.addEventListener('resize', onWindowResize, false);
		container.addEventListener('mousemove', onMouseMove, false);
		container.addEventListener('mousedown', onMouseDown, false);
		container.addEventListener('mouseup', onMouseUp, false);
		container.addEventListener('click', onClick, false);

		const animate = function() {
			requestAnimationFrame(animate);

			// sphere.rotation.y += 0.01;
			// cylinder.rotation.y += 0.02;
			// dodecahedron.rotation.y += 0.03;
			// mesh.rotation.y += 0.03;

			renderer.render(scene, camera);
		};

		// animate();
	})();

	function onWindowResize() {
		w = window.innerWidth;
		h = window.innerHeight / 2;

		camera.aspect = w / h;
		camera.updateProjectionMatrix();
		renderer.setSize(w, h);

		cam2.aspect = w / h;
		cam2.updateProjectionMatrix();
		renderer2.setSize(w, h);
	}

	function onMouseMove(event) {
		event.preventDefault();
		if (isDown) isDragging = true;

		if (!isDragging) {
			// mouse.x = event.clientX / w * 2 - 1;
			// mouse.y = -(event.clientY / h) * 2 + 1;
			// raycaster.setFromCamera(mouse, camera);
			// var intersects = raycaster.intersectObjects(children.children);
			// if (intersects.length > 0) {
			// 	if (INTERSECTED != intersects[0].object) {
			// 		if (INTERSECTED) INTERSECTED.material.emissive.setHex(INTERSECTED.currentHex);
			// 		INTERSECTED = intersects[0].object;
			// 		bbox.update(INTERSECTED);
			// 		INTERSECTED.currentHex = INTERSECTED.material.emissive.getHex();
			// 		INTERSECTED.material.emissive.setHex(0xffff00);
			// 		container.style.cursor = 'pointer';
			// 		console.log(INTERSECTED);
			// 	}
			// } else {
			// 	if (INTERSECTED) INTERSECTED.material.emissive.setHex(INTERSECTED.currentHex);
			// 	INTERSECTED = null;
			// 	container.style.cursor = 'auto';
			// }
		}
	}

	function onClick(event) {
		event.preventDefault();
		if (!isDragging && INTERSECTED) {
			// var bsphere = bbox.geometry.boundingSphere;
			// var centroid = bsphere.center;
			// controls.target.copy(centroid);
			// controls.update();
			// camera.position.setY(centroid.y);
			// camera.position.sub(centroid).normalize().multiplyScalar(bsphere.radius * 1.7).add(centroid);
			// controls.update();
		}
		mouse.x = event.clientX / w * 2 - 1;
		mouse.y = -(event.clientY / h) * 2 + 1;

		raycaster.setFromCamera(mouse, camera);
		var intersects = raycaster.intersectObjects(children.children);
		if (intersects.length > 0) {
			if (INTERSECTED != intersects[0].object) {
				if (INTERSECTED) INTERSECTED.material.emissive.setHex(INTERSECTED.currentHex);
				INTERSECTED = intersects[0].object;
				bbox.update(INTERSECTED);
				INTERSECTED.currentHex = INTERSECTED.material.emissive.getHex();
				INTERSECTED.material.emissive.setHex(0xffffff);
				container.style.cursor = 'pointer';
				console.log(INTERSECTED);
			}
		} else {
			if (INTERSECTED) INTERSECTED.material.emissive.setHex(INTERSECTED.currentHex);
			INTERSECTED = null;
			container.style.cursor = 'auto';
		}
	}

	function onMouseDown(event) {
		event.preventDefault();
		isDown = true;
	}

	function onMouseUp(event) {
		event.preventDefault();
		isDown = false;
		isDragging = false;
	}

	(function animate() {
		requestAnimationFrame(animate);

		camHelper.visible = false;
		bbox.visible = false;
		renderer.render(scene, camera);

		camHelper.visible = true;
		bbox.visible = true;
		renderer2.render(scene, cam2);
		stats.update();
	})();
});
