-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: mysql
-- Generation Time: Mar 05, 2021 at 03:11 AM
-- Server version: 5.7.33
-- PHP Version: 7.4.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `web_demo`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `getAllTrips` ()  NO SQL
SELECT * FROM `trip`$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_checkPoint` (IN `p_location` VARCHAR(250))  BEGIN
    select * from point_running where 	p_address = p_location;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_createBooking` (IN `o_id_user` INT(10), IN `o_name` VARCHAR(50), IN `o_phone` VARCHAR(50), IN `o_pickup_point_start` VARCHAR(500), IN `o_address_start` VARCHAR(250), IN `o_pickup_point_end` VARCHAR(500), IN `o_address_end` VARCHAR(50), IN `o_chair_type` VARCHAR(20), IN `o_quantity` VARCHAR(50), IN `o_start_date` DATE, IN `o_start_time` VARCHAR(10), IN `o_stop_date` DATE, IN `o_stop_time` VARCHAR(10))  BEGIN
    INSERT INTO order_trip(
        user_id,
        NAME,
        phone,
        pickup_point_start,
        address_start,
        pickup_point_end,
        address_end,
        chair_type,
        quantity,
        start_date,
        start_time,
        stop_date,
        stop_time
    )
VALUES(
    o_id_user,
    o_name,
    o_phone,
    o_pickup_point_start,
    o_address_start,
    o_pickup_point_end,
    o_address_end,
    o_chair_type,
    o_quantity,
    o_start_date,
    o_start_time,
    o_stop_date,
    o_stop_time
);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_createPointRunning` (IN `vl_p_name` VARCHAR(255), IN `vl_p_address` VARCHAR(255), IN `vl_p_pick_up` INT(10), IN `vl_p_drop` INT(10), IN `vl_trip_id` INT(10))  NO SQL
INSERT INTO point_running(
    p_name,
    p_address,
    p_pick_up,
    p_drop,
    trip_id
)
VALUES(
    vl_p_name,
    vl_p_address,
    vl_p_pick_up,
    vl_p_drop,
    vl_trip_id
)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_createTrip` (IN `vl_car_id` INT(11), IN `vl_blank_seats` INT(11), IN `vl_seated` INT(11), IN `vl_name_start_point` TEXT, IN `vl_start_point` VARCHAR(50), IN `vl_name_stop_point` TEXT, IN `vl_stop_point` VARCHAR(50), IN `vl_note` TEXT)  NO SQL
INSERT INTO trip(
    car_id,
    blank_seats,
    seated,
    name_start_point,
    start_point,
    name_stop_point,
    stop_point,
    note
)
VALUES(
    vl_car_id,
    vl_blank_seats,
    vl_seated,
    vl_name_start_point,
    vl_start_point,
    vl_name_stop_point,
    vl_stop_point,
    vl_note
)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_createUser` (IN `p_name` VARCHAR(200), IN `p_username` VARCHAR(200), IN `p_password` VARCHAR(200), IN `p_phone` VARCHAR(15), IN `p_birth` DATE)  BEGIN
	if ( select exists (select user_username from tbl_user where user_username = p_username) ) THEN
	
		select 'Username Exists !!';
	
	ELSE
	
		insert into tbl_user
		(
			user_name,
			user_username,
			user_password,
            user_phone_number,
            user_birth_date
		)
		values
		(
			p_name,
			p_username,
			p_password,
            p_phone,
            p_birth
		);
	
	END IF;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_getDetailTrip` (IN `p_trip_id` INT(11))  SELECT
        `car_id`,
        `blank_seats`,
        `seated`,
        `name_start_point`,
        `start_point`,
        `name_stop_point`,
        `stop_point`,
        `note`
    FROM
        `trip`
    WHERE
        trip.id = p_trip_id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_getOrder` ()  BEGIN
    select id from order_trip;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_getPoint` (IN `p_trip_id` INT(11))  BEGIN
select `p_name`,`p_address`,`p_pick_up`,`p_drop` from point_running where trip_id = p_trip_id ;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_updateOrderTrip` (IN `vl_id` INT(11), IN `vl_trip_id` INT(11))  NO SQL
UPDATE order_trip
SET
    trip_id = vl_trip_id,
    updated_at = CURRENT_TIMESTAMP
WHERE id = vl_id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_validateLogin` (IN `p_username` LONGTEXT)  BEGIN
    select * from tbl_user where user_username = p_username;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `car`
--

CREATE TABLE `car` (
  `id` int(11) NOT NULL,
  `car_number` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `license_plates` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `driver` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ordinaly_chair_number` int(11) NOT NULL,
  `disability_seat_number` int(11) NOT NULL,
  `type` int(11) NOT NULL,
  `info` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `car`
--

INSERT INTO `car` (`id`, `car_number`, `license_plates`, `driver`, `ordinaly_chair_number`, `disability_seat_number`, `type`, `info`) VALUES
(1, '1', '123', 'zxc', 20, 0, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `order_trip`
--

CREATE TABLE `order_trip` (
  `id` int(11) NOT NULL,
  `user_id` int(10) NOT NULL,
  `trip_id` int(11) UNSIGNED DEFAULT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pickup_point_start` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address_start` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pickup_point_end` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address_end` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `chair_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `start_date` date NOT NULL,
  `start_time` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `stop_date` date NOT NULL,
  `stop_time` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `order_trip`
--

INSERT INTO `order_trip` (`id`, `user_id`, `trip_id`, `name`, `phone`, `pickup_point_start`, `address_start`, `pickup_point_end`, `address_end`, `chair_type`, `quantity`, `start_date`, `start_time`, `stop_date`, `stop_time`, `created_at`, `updated_at`) VALUES
(868, 1, NULL, 'Marcil Atly', '685-800-3599', '凤凰山体育中心, 杜太路, 太华社区, 大丰街道, 成都市, 四川省, 中国', '30.76743,104.076509', '凤凰山体育中心, 杜太路, 太华社区, 大丰街道, 成都市, 四川省, 中国', '30.58951,104.0637', '1', '1', '2016-11-01', '07:33', '2016-11-01', '08:07', '2021-03-04 10:54:33', '2021-03-04 10:54:33'),
(869, 1, NULL, 'Mée Exped', '881-960-2771', '同兴北街, 青羊区, 成都市, 四川省, 610091, 中国', '30.689007,104.019699', '同兴北街, 青羊区, 成都市, 四川省, 610091, 中国', '30.66395,104.105324', '1', '1', '2016-11-01', '12:55', '2016-11-01', '13:16', '2021-03-04 10:54:34', '2021-03-04 10:54:34'),
(870, 1, NULL, 'Sciand Fed', '477-448-9452', '火炬时代, 高朋东路, 科园社区, 肖家河街道, 高新南区, 武侯区, 成都市, 四川省, 028, 中国', '30.62269,104.03609', '火炬时代, 高朋东路, 科园社区, 肖家河街道, 高新南区, 武侯区, 成都市, 四川省, 028, 中国', '30.68232,104.04386', '1', '1', '2016-11-01', '08:44', '2016-11-01', '09:04', '2021-03-04 10:54:35', '2021-03-04 10:54:35'),
(871, 1, NULL, 'As Eurega', '299-213-0383', '5栋, 双庆路, 万年场街道, 成华区 (Chenghua), 成都市, 四川省, 610051, 中国', '30.652313,104.115997', '5栋, 双庆路, 万年场街道, 成华区 (Chenghua), 成都市, 四川省, 610051, 中国', '30.695113,104.104421', '1', '1', '2016-10-31', '23:53', '2016-11-01', '00:02', '2021-03-04 10:54:36', '2021-03-04 10:54:36'),
(872, 1, NULL, 'Of Dis', '629-242-6618', '灯笼街, 八宝街社区, 草市街街道, 成都市, 四川省, 610015, 中国', '30.67676,104.05933', '灯笼街, 八宝街社区, 草市街街道, 成都市, 四川省, 610015, 中国', '30.67693,104.00017', '1', '1', '2016-11-01', '10:54', '2016-11-01', '11:13', '2021-03-04 10:54:37', '2021-03-04 10:54:37'),
(873, 1, NULL, 'Oce Counes', '356-193-9018', '5栋, 双庆路, 万年场街道, 成华区 (Chenghua), 成都市, 四川省, 610051, 中国', '30.652313,104.115997', '5栋, 双庆路, 万年场街道, 成华区 (Chenghua), 成都市, 四川省, 610051, 中国', '30.695113,104.104421', '1', '1', '2016-10-31', '23:53', '2016-11-01', '00:02', '2021-03-04 10:54:38', '2021-03-04 10:54:38'),
(874, 1, NULL, 'Thic Curd', '629-770-2653', '香木林花园, 府青路街道, 成华区 (Chenghua), 成都市, 四川省, 610054, 中国', '30.687676,104.108977', '香木林花园, 府青路街道, 成华区 (Chenghua), 成都市, 四川省, 610054, 中国', '30.71717,104.04279', '1', '1', '2016-11-01', '00:08', '2016-11-01', '00:29', '2021-03-04 10:54:39', '2021-03-04 10:54:39'),
(875, 1, NULL, 'Comen Ise', '944-210-6257', '交大路, 交桂二巷1号院, 金牛区, 成都市, 四川省, 610031, 中国', '30.708862,104.037636', '交大路, 交桂二巷1号院, 金牛区, 成都市, 四川省, 610031, 中国', '30.7663,104.0515', '1', '1', '2016-11-01', '00:35', '2016-11-01', '00:56', '2021-03-04 10:54:40', '2021-03-04 10:54:40'),
(876, 1, NULL, 'Alial Dopenc', '875-136-0635', '新都区, 成都市, 四川省, 610036, 中国', '30.77018,104.054981', '新都区, 成都市, 四川省, 610036, 中国', '30.702131,104.073181', '1', '1', '2016-11-01', '01:02', '2016-11-01', '01:27', '2021-03-04 10:54:41', '2021-03-04 10:54:41'),
(877, 1, NULL, 'Daterv Valled', '738-243-8939', '青龙街道, 成华区 (Chenghua), 成都市, 四川省, 610081, 中国', '30.703971,104.09464', '青龙街道, 成华区 (Chenghua), 成都市, 四川省, 610081, 中国', '30.65085,104.08927', '1', '1', '2016-11-01', '01:46', '2016-11-01', '02:15', '2021-03-04 10:54:42', '2021-03-04 10:54:42');

-- --------------------------------------------------------

--
-- Table structure for table `point_running`
--

CREATE TABLE `point_running` (
  `id` int(10) NOT NULL,
  `p_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `p_address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `p_pick_up` int(10) NOT NULL,
  `p_drop` int(10) NOT NULL,
  `trip_id` int(10) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `user_id` bigint(20) NOT NULL,
  `user_name` longtext COLLATE utf8mb4_unicode_ci,
  `user_username` varchar(450) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_password` varchar(450) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_phone_number` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_birth_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`user_id`, `user_name`, `user_username`, `user_password`, `user_phone_number`, `user_birth_date`) VALUES
(20, 'khoi', 'dtkhoimail@gmail.com', 'pbkdf2:sha256:150000$Ob27Q6kB$4ae6f83cd3d62a9364aa282aeb3a9789f25ed930576f8ba129dddcdff92c1661', '0123456789', '2021-02-04'),
(21, 'dsadsda', 'dtkhoimail30@gmail.com', 'pbkdf2:sha256:150000$Ael4Wpjh$765006e2b5cc2b4e2750cd28ae9fe4af4bce3ca0e3d7f9e8ebcc5bbfaad57c3d', '313213546545', '2021-02-05'),
(22, '11111111', 'dtkhoimail32@gmail.com', 'pbkdf2:sha256:150000$RsC7jeEz$96b4c2f3a89150957c20aeda03575416704ac42ee205269676a5e026d238951f', '313213546545', '2021-02-06'),
(23, 'zxcxzcxzc', 'dtkhoimail3cxzcx0@gmail.com', 'pbkdf2:sha256:150000$CWkxpsCe$4abbdc3d547d6fcf13f5d917790fac0060b30e722033843e837fdc8e14cf48bf', '0123456789', '2021-02-06'),
(25, 'vcvxc', 'dtkhoimail30@gmail.comcxvxcvxc', 'pbkdf2:sha256:150000$4tCuXdJU$ba49f683fa7dc4b1d0a7e6f6be8e6c6da0d3d336944acfbb5db9e174f7325c6f', '0123456789', '2021-02-05'),
(26, 'vcvxc', 'dtkhoimvcbvcbvcbail30@gmail.com', 'pbkdf2:sha256:150000$u30gVYzl$585ad61101c283d8c639ac985ae33ed8d5ab6ba8485c85e2806df6c239918fd4', '0123456789', '2021-02-05'),
(27, 'vcvxc', 'dtkhoimvcbvcbbnvcbail30@gmail.com', 'pbkdf2:sha256:150000$SUuSyoli$b5c5bae0fc5d1e919474612bc8aaf2218ce0ab5997fcffca3bb4c147ff463e24', '0123456789', '2021-02-05'),
(28, 'xcvxcv', 'dtkhoivcvcvcmail30@gmail.com', 'pbkdf2:sha256:150000$Ijb3eg4I$80a664d8cbf8fa36c992aed256bd5a599e3f6487b05b17246ec88529edb9b383', '0123456789', '2021-02-06'),
(29, 'xcvxcv', 'dtkhoivcvcvhcmail30@gmail.com', 'pbkdf2:sha256:150000$zGVuRuAK$6cf9822052dfe302523552fa46285f62a5377b6ea248b0dec920db2be7bdee08', '0123456789', '2021-02-06'),
(30, 'fsdf', 'dtkhoidsfsdmail30@gmail.com', 'pbkdf2:sha256:150000$hjpsPRV4$8789598989a84c58d3986fc004060d35a3acf5b3b254461a347a1d134e8d6346', '313213546545', '2021-02-06');

-- --------------------------------------------------------

--
-- Table structure for table `trip`
--

CREATE TABLE `trip` (
  `id` int(11) NOT NULL,
  `car_id` int(11) NOT NULL,
  `blank_seats` int(11) NOT NULL,
  `seated` int(11) NOT NULL,
  `name_start_point` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `start_point` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_stop_point` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `stop_point` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `note` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `car`
--
ALTER TABLE `car`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_trip`
--
ALTER TABLE `order_trip`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `point_running`
--
ALTER TABLE `point_running`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `trip`
--
ALTER TABLE `trip`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `car`
--
ALTER TABLE `car`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `order_trip`
--
ALTER TABLE `order_trip`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=878;

--
-- AUTO_INCREMENT for table `point_running`
--
ALTER TABLE `point_running`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=725;

--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `user_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `trip`
--
ALTER TABLE `trip`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=58;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
