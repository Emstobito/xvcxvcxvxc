$(document).ready(function() {
	listNameFile();
});
var iconStart = L.icon({
	iconUrl: 'http://' + serverIp + ':8002/static/img/start-icon.png',
	iconSize: [ 14, 20 ],
	iconAnchor: [ 7, 20 ]
});
var iconEnd = L.icon({
	iconUrl: 'http://' + serverIp + ':8002/static/img/end-icon.png',
	iconSize: [ 14, 20 ],
	iconAnchor: [ 7, 20 ]
});
var iconDepot = L.icon({
	iconUrl: 'http://' + serverIp + ':8002/static/img/car-icon.png',
	iconSize: [ 30, 30 ],
	iconAnchor: [ 15, 15 ]
});
// var depot = [ 21.04232, 105.81245 ];
var depot = [ 28.521234, 77.156789 ];
// var limitBor = [35.7014, 139.8663, 35.8195, 139.6211];
var limitBor = [ 28.5881017, 77.0251624, 28.489506, 77.3182893 ];
var arrayColor = [ '#31c594', '#717DF5', '#A971F5', '#A260A9', '#a97d1e', '#6e7539', '#FF5733', '#CE567A', '#9CCB8C' ];
var arrayEnd = [
	[ 21.0122, 105.815 ],
	[ 21.0246, 105.8082 ],
	[ 21.0156, 105.8271 ],
	[ 21.0265, 105.8392 ],
	[ 21.00813, 105.80351 ],
	[ 21.00168, 105.83972 ],
	[ 21.02049, 105.76587 ]
];
var dataBookings = [];
var strMatrixData = '';
var dataOrDistance = [];
var dataAllPoint = [];
var dataTripCv = [];

getMatrixDistance = (matrixData) => {
	if (getMatrixDistance !== '') {
		$.ajax({
			type: 'POST',
			url: server_3 + '/get-distanceMatrix.html',
			data: { matrix: matrixData },
			success: function(res) {
				getOrDistance(res.data.distances);
			},
			error: function(e) {}
		});
	}
};
getOrDistance = (matrixDistance) => {
	if (getOrDistance !== '') {
		$.ajax({
			type: 'POST',
			url: server_3 + '/orDistances',
			// data: { matrixDistance: JSON.stringify({ matrixDistance }) },
			data: { matrixDistance: JSON.stringify({ matrixDistance }) },
			success: function(res) {
				dataOrDistance = res.data;
				renderTrip(dataOrDistance);

				console.log(res.data);
				// drawTrip(res);
			},
			error: function(e) {
				// console.log(e.responseText);
			}
		});
	}
};

function setDataTable(i, colorRd, start, end, timeStart, nameStart, nameEnd) {
	let html =
		`
        <tr style="color:` +
		colorRd +
		`;">
            <td>` +
		(i + 1) +
		`</td>
            <td><span class="hiddent-text">` +
		nameStart +
		`</span></td>
            <td><span>` +
		start[0] +
		`</span>,<span>` +
		start[1] +
		`</span></td>
            <td><span class="hiddent-text">` +
		nameEnd +
		`</span></td>
            <td><span>` +
		end[0] +
		`</span>,<span>` +
		end[1] +
		`</span></td>
            <td>` +
		timeStart +
		`</td>
        </tr>
    `;
	$('.orders').append(html);
}

function getRandomColor() {
	return '#' + Math.floor(Math.random() * 16777215).toString(16);
}

// Booking
async function bookingDataDemo() {
	if ($('#order-number').val() == '') {
		return toastr.error('Error !');
	}
	dataBookings = [];
	switchLoading(true);
	var ordersN = $('#order-number').val();
	for (var i = 0; i < ordersN; i++) {
		let colorRd = getRandomColor();
		var startLat = (Math.random() * (limitBor[0] - limitBor[2]) + limitBor[2]).toFixed(4);
		var startLng = (Math.random() * (limitBor[1] - limitBor[3]) + limitBor[3]).toFixed(4);
		var endLat = (Math.random() * (limitBor[0] - limitBor[2]) + limitBor[2]).toFixed(4);
		var endLng = (Math.random() * (limitBor[1] - limitBor[3]) + limitBor[3]).toFixed(4);
		var minStart = Math.floor(Math.random() * 2) * 30;
		if (minStart == 0) {
			minStart = '00';
		}
		var hourStart = Math.floor(Math.random() * (20 - 8)) + 8;
		var timeStart = String(hourStart) + ':' + minStart;
		var tz = '';
		if (hourStart <= 11) {
			tz = 's';
		} else if (hourStart > 11 && hourStart <= 14) {
			tz = 'tr';
		} else if (hourStart > 14 && hourStart <= 16) {
			tz = 'c';
		} else {
			tz = 't';
		}
		var start = [ startLat, startLng ];
		var end = [ endLat, endLng ];
		$('.numberOrder-popup-' + (i + 1) + ' .leaflet-popup-content-wrapper').css('background', colorRd);
		var utc = new Date().toJSON().slice(0, 10).replace(/-/g, '/');
		// let nameStart = await getNameAddress(start.toString())
		// let nameEnd = await getNameAddress(end.toString())
		dataBookings.push(pushDataBooking(start, end, utc, timeStart));
	}
	bookingData();
}
function pushDataBooking(start, end, utc, timeStart) {
	return {
		address_start: start.toString(),
		address_end: end.toString(),
		start_date: utc,
		start_time: timeStart,
		stop_date: utc,
		stop_time: timeStart
	};
}

function bookingData() {
	$.ajax({
		url: server_3 + '/booking-array',
		data: { databooking: JSON.stringify(dataBookings) },
		type: 'POST',
		success: function(response) {
			switchLoading(false);
			if (response.status == 200) {
				toastr.success(response.data.message);
			}
			console.log(response);
			loadDataBooking();
		},
		error: function(e) {
			toastr.error('Error !');
		}
	});
}
function destroyBooking() {
	resetTable();
	$.ajax({
		url: server_3 + '/destroy-booking',
		data: {},
		type: 'POST',
		success: function(response) {
			if (response.status == 200) {
				toastr.success(response.data.message);
			}
			console.log(response);
		},
		error: function(e) {
			toastr.error('Error !');
		}
	});
}
function loadDataBooking() {
	resetTable();
	switchLoading(true);
	$.ajax({
		url: server_3 + '/get-all-booking',
		data: {},
		type: 'GET',
		success: function(response) {
			if (response.status == 200) {
				if (response.data.data.length > 0) {
					toastr.success(response.data.message);
				} else {
					toastr.warning(response.data.message);
				}
			}
			setTimeout((e) => {
				switchLoading(false);
			}, 300);
			strMatrixData = response.data.strMatrixData;
			dataAllPoint = response.data.dataAllPoint;
			renderDataBooking(response.data.data);
		},
		error: function(e) {
			toastr.error('Error !');
		}
	});
}
function renderDataBooking(data) {
	data.map((item, key) => {
		let colorRd = getRandomColor();
		setColItem(item, key, colorRd);
	});
}
function setColItem(item, key, colorRd) {
	let html =
		`
        <tr style="color:` +
		colorRd +
		`;">
            <td>` +
		(key + 1) +
		`</td>
            <td><span class="hiddent-text">` +
		item['pickup_point_start'] +
		`</span></td>
            <td><span>` +
		item['address_start'] +
		`</span></td>
            <td><span class="hiddent-text">` +
		item['pickup_point_end'] +
		`</span></td>
            <td><span>` +
		item['address_end'] +
		`</span></td>
            <td>` +
		item['start_time'] +
		`</td>
        </tr>
    `;
	$('.list-booking').append(html);
}
function resetTable() {
	$('.list-booking').html('');
	$('.list-trip').html('');
}

// Arrange Trips

async function loadArrangeTrips() {
	switchLoading(true);
	if (strMatrixData.length > 0) {
		await getMatrixDistance(strMatrixData);
	} else {
		switchLoading(false);
		toastr.warning('No data!');
	}
}

function renderTrip(dataOrDistance) {
	switchLoading(false);
	$('.list-trip').html('');
	dataOrDistance.map((item, key) => {
		dataTripCv.push([]);
		let html =
			`<h4>Detail trip: ` +
			(key + 1) +
			`</h4>
            <div class="list-table">
                <ul>
                    <li></li>
                    <li>Name</li>
                    <li>Address</li>
                    <li>Activity</li>
                </ul>
                ` +
			renderHtml(item, key) +
			`
            </div>`;
		$('.list-trip').append(html);
	});
}
function renderHtml(item, key) {
	console.log(item);
	let html = '';
	item.map((i, k) => {
		dataTripCv[key].push(dataAllPoint[i]);
		if (dataAllPoint[i]['type'] != 'start') {
			html +=
				`<ul>
                        <li>` +
				(k + 1) +
				`</li>
                        <li>` +
				dataAllPoint[i]['name'] +
				`</li>
                        <li>` +
				dataAllPoint[i]['point_name'] +
				`</li>
                        <li>` +
				(dataAllPoint[i]['type'] == 'up' ? 'Pick Up' : 'Drop Off') +
				`</li>
                    </ul>`;
		} else {
			html +=
				`<ul>
                        <li>` +
				(k + 1) +
				`</li>
                        <li>Parking</li>
                        <li>` +
				dataAllPoint[i]['point_name'] +
				`</li>
                        <li>Parking</li>
                    </ul>`;
		}
	});
	return html;
}

function handleSaveTrip() {
	switchLoading(true);
	if (dataTripCv.length > 0) {
		$.ajax({
			type: 'POST',
			url: server_3 + '/save_trip',
			data: { dataTripCv: JSON.stringify({ dataTripCv }) },
			success: function(response) {
				setTimeout((e) => {
					switchLoading(false);
					resetTable();
					if (response.status == 200) {
						toastr.success(response.data.message);
					}
					console.log(response.data);
				}, 500);
			},
			error: function(e) {
				toastr.error('Error !');
			}
		});
	} else {
		setTimeout((e) => {
			switchLoading(false);
			toastr.warning('No data!');
		}, 500);
	}
}

function handleBooking() {
	if ($('#listFileData').val() == '' || $('#numberRecord').val() == '') {
		return toastr.error('Error !');
	}
	switchLoading(true);
	$.ajax({
		url: server_3 + '/booking-data-didi',
		type: 'POST',
		data: { name_file: $('#listFileData').val(), number_record: $('#numberRecord').val() },
		success: function(response) {
			switchLoading(false);
			if (response.status == 200) {
				toastr.success(response.data.message);
			}
			loadDataBooking();
		},
		error: function(e) {
			console.log(e);
		}
	});
}

function listNameFile() {
	$.ajax({
		url: server_2 + '/get-list-file',
		type: 'GET',
		success: function(response) {
			let data = response.data;
			data.map((item, key) => {
				$('#listFileData').append(`<option value="` + item + `">` + item + `</option>`);
			});
		},
		error: function(e) {
			console.log(e);
		}
	});
}

// no use _---------------------------------------------
function drawTrip(res) {
	var ordersStartL = [ depot ];
	var num = $('.orders tr').length;
	for (n = 1; n < num; n++) {
		var locStart = [
			parseFloat($('.orders tr:nth-child(' + (n + 1) + ') td:nth-child(2) span:first-child').text()),
			parseFloat($('.orders tr:nth-child(' + (n + 1) + ') td:nth-child(2) span:last-child').text())
		];
		var locEnd = [
			parseFloat($('.orders tr:nth-child(' + (n + 1) + ') td:nth-child(3) span:first-child').text()),
			parseFloat($('.orders tr:nth-child(' + (n + 1) + ') td:nth-child(3) span:last-child').text())
		];
		ordersStartL.push(locStart);
		ordersStartL.push(locEnd);
	}
	console.log(ordersStartL);
	var numberTrip = res.data.length;
	for (i = 0; i < numberTrip; i++) {
		var numberLine = res.data[i].length;
		for (j = 0; j < numberLine - 1; j++) {
			var polyline = L.polyline([ ordersStartL[res.data[i][j]], ordersStartL[res.data[i][j + 1]] ], {
				color: '#000',
				dashArray: '10 10',
				weight: 2,
				className: 'tripLine tripLine-' + (i + 1)
			}).addTo(map);
		}
		var print = res.data[i].toString();
		$('.table-box').append('<h3 class="trip" trip="' + (i + 1) + '">Trip ' + (i + 1) + ':' + print + '</h3>');
	}
	$('.trip').click(function() {
		var trip = $(this).attr('trip');
		$('.tripLine').addClass('disable');
		$('.tripLine-' + trip).remove('disable').addClass('active');
	});
}
async function createOrder() {
	console.clear();

	var ordersStartL = [ depot ];
	var ordersStartT = [];
	var distanceMatrix = [];
	var markerDepot = L.marker(depot, { icon: iconDepot }).addTo(map);
	L.DomUtil.addClass(markerDepot._icon, 'circleK');
	map.setView([ 21.0155, 105.8029 ], 13);
	var ordersN = $('#order-number').val();
	if (ordersN > 10) {
		// ordersN = 10;
	}
	var stringData = depot[1] + ',' + depot[0];
	for (var i = 0; i < ordersN; ++i) {
		let colorRd = getRandomColor();
		var random = Math.floor(Math.random() * arrayEnd.length);
		var startLat = (Math.random() * (limitBor[0] - limitBor[2]) + limitBor[2]).toFixed(4);
		var startLng = (Math.random() * (limitBor[1] - limitBor[3]) + limitBor[3]).toFixed(4);
		var endLat = (Math.random() * (limitBor[0] - limitBor[2]) + limitBor[2]).toFixed(4);
		var endLng = (Math.random() * (limitBor[1] - limitBor[3]) + limitBor[3]).toFixed(4);
		stringData = stringData + ';' + startLng + ',' + startLat + ';' + endLng + ',' + endLat;
		var minStart = Math.floor(Math.random() * 2) * 30;
		if (minStart == 0) {
			minStart = '00';
		}
		var hourStart = Math.floor(Math.random() * (20 - 8)) + 8;
		var timeStart = String(hourStart) + ':' + minStart;
		var tz = '';
		if (hourStart <= 11) {
			tz = 's';
		} else if (hourStart > 11 && hourStart <= 14) {
			tz = 'tr';
		} else if (hourStart > 14 && hourStart <= 16) {
			tz = 'c';
		} else {
			tz = 't';
		}
		var start = [ startLat, startLng ];
		var end = [ endLat, endLng ];
		// var end = arrayEnd[random];
		ordersStartL.push(start);
		ordersStartL.push(end);
		ordersStartT.push([ hourStart, minStart ]);
		var markerStart = L.marker(start, { icon: iconStart }).addTo(map).bindPopup('<b>' + (2 * i + 1) + '</b>', {
			autoClose: false,
			className: 'numberOrder-popup numberOrder-popup-' + (i + 1) + ' tz-' + tz
		});
		var markerEnd = L.marker(end, { icon: iconEnd }).addTo(map).bindPopup('<b>' + (2 * i + 2) + '</b>', {
			autoClose: false,
			className: 'numberOrder-popup numberOrder-popup-' + (i + 1) + ' tz-' + tz
		});
		L.DomUtil.addClass(markerStart._icon, 'markerStart-' + (i + 1));
		L.DomUtil.addClass(markerEnd._icon, 'markerEnd-' + (i + 1));
		markerStart.openPopup();
		markerEnd.openPopup();
		$('.numberOrder-popup-' + (i + 1) + ' .leaflet-popup-content-wrapper').css('background', colorRd);
		var polyline = L.polyline([ [ start, end ] ], { color: colorRd }).addTo(map);
		var utc = new Date().toJSON().slice(0, 10).replace(/-/g, '/');
		let nameStart = await getName(start.toString());
		let nameEnd = await getName(end.toString());
		setDataTable(i, colorRd, start, end, timeStart, nameStart, nameEnd);
		dataBookings.push({
			user_id: 1,
			nameBooking: 'Trinh Huu Duc',
			phoneBooking: '0333980209',
			pickup_point_start: nameStart,
			address_start: start.toString(),
			pickup_point_end: nameEnd,
			address_end: end.toString(),
			chair_type: 0,
			quantity: 1,
			start_date: utc,
			start_time: timeStart,
			stop_date: utc,
			stop_time: timeStart
		});
	}
	console.log('stringData', stringData);
	console.log('dataBookings', dataBookings);
	getMatrixDistance(stringData);
	$('.leaflet-interactive').attr('stroke-width', '2');
	$('#crOd').remove();
	$('#order-number').remove();
	$('.orders tr').click(function() {
		var index = $('.orders tr').index(this);
		$('.orders tr').removeClass('selected');
		$(this).addClass('selected');
		$('.line-selected').removeClass('line-selected');
		$('.leaflet-overlay-pane path').addClass('line-not-selected');
		$('.leaflet-overlay-pane path:nth-child(' + index + ')')
			.removeClass('line-not-selected')
			.addClass('line-selected');
		$('.marker-selected').removeClass('marker-selected');
		$(
			'.leaflet-marker-pane img:not(.circleK):not(.markerStart-' + index + '):not(.markerEnd-' + index + ')'
		).addClass('marker-not-selected');
		$('.leaflet-marker-pane .numberOrder-popup-' + index)
			.removeClass('marker-not-selected')
			.addClass('marker-selected');
		// $('.leaflet-marker-pane img:nth-child(' + (2 * index + 1) + ')').removeClass('marker-not-selected').addClass('marker-selected');
		$('.numberOrder-popup').addClass('marker-not-selected');
		$('.numberOrder-popup-' + index).removeClass('marker-not-selected').addClass('marker-selected');
		console.log(index);
	});
	$('#show-all').removeClass('d-none');
	var circle = L.circle([ 35.7387, 139.7193 ], {
		color: '#f035',
		fillColor: '#f03',
		fillOpacity: 0.05,
		radius: 13000,
		className: 'circleK'
	}).addTo(map);
}
function showAll() {
	$('.line-not-selected').removeClass('line-not-selected');
	$('.marker-not-selected').removeClass('marker-not-selected');
	$('.orders tr').removeClass('selected');
	$('.tripLine').removeClass('disable');
}
function getNameAddress(value) {
	return new Promise((resolve) => {
		$.ajax({
			type: 'POST',
			url: server_3 + '/get_name_address',
			data: { coordinates: value },
			success: function(res) {
				if (res.status == 200) {
					resolve(res.data.name_address);
				} else {
					resolve(value);
				}
			}
		});
	});
}
// no use _---------------------------------------------
