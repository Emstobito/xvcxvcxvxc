$(document).ready(function () {
    sessionStorage.setItem("dataTrip", []);
    sessionStorage.setItem("listMarker", []);
    switchLoading(true)
    getApi();
});
var dataTrip = {};
getApi = async () => {
    let result = {}
    await $.ajax({
        type: "POST",
        data: {"trip_id": getParameterByName('trip_id')},
        url: server_3 + "/get_trip",
        success: function (res) {
            result = res.data
        }
    });
    dataTrip = result
    sessionStorage.setItem("dataTrip", JSON.stringify(dataTrip));
    await loadmaps()
    await renderListPoinToUI(result)
    await btnLoadRouters()
}
function renderListPoinToUI(result) {
    $("#nameCar").html(result.car_id);
    $("#numberSeats").html(result.blank_seats);
    result.list_point.map((item, key) => {
        let i = 0;
        switch (item.type) {
            case "start":
                $("#carStart").html(item.name);
                break;
            case "go":
                $("#listPickPoints").append(
                    `<tr>
                        <td>`+ key + `</td>
                        <td>`+ item.name + `</td>
                    </tr>`
                );
                break;
            case "stop":
                $("#carEnd").html(item.name);
                break;
            default:
                break;
        }
        i++
    })
    map.invalidateSize()
}
function getParameterByName(name, url = window.location.href) {
    name = name.replace(/[\[\]]/g, '\\$&');
    var regex = new RegExp('[?&]' + name + '(=([^&#]*)|&|#|$)'),
        results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, ' '));
}

async function btnLoadRouters() {
    map.invalidateSize()
    let searchRoute = ""
    let locationLength = dataTrip.list_point.length;
    dataTrip.list_point.map((item, key) => {
        searchRoute += locationLength - 1 != key ? reverseString(item.address) + ";" : reverseString(item.address);
    })
    map.setView(dataTrip.name_start_point.split(","), 14);
    let random = roundUp(Math.random() * 20, 0)
    for (let i = 0; i < random; i++) {
        let name_start_point = dataTrip.name_start_point.split(",")
        let r = 0.15;
        var limitBor = [parseFloat(name_start_point[0]) - r, parseFloat(name_start_point[1]) - r, parseFloat(name_start_point[0]) + r, parseFloat(name_start_point[1]) + r];
        // let limit = roundUp(Math.random() * 10, 0) > 5 ? 1 : -1;
        let circleLat  = roundUp(Math.random() * (limitBor[0] - limitBor[2]) + limitBor[2], 6);
        let circleLng  = roundUp(Math.random() * (limitBor[1] - limitBor[3]) + limitBor[3], 6);

        console.log([circleLat, circleLng]);
        L.circle([circleLat, circleLng], {
            color: 'red',
            fillColor: '#f03',
            fillOpacity: 0.5,
            radius: 150
        }).addTo(map).bindPopup("<h5 class='m-0'>Covid-19</h5>.", { closeOnClick: false, autoPan: false, autoClose: true, zoomAnimation: false });
    }
    await getDistance(searchRoute);
};

mkPopup = (item) => {
    // <div class="txt-title-popup">`+ item.type +`</div>
    return `
		<div class="row box-info">
            <div class="col-sm-6 offset-md-3 col-smail mb-3">
                <div class="d-flex justify-content-center">
                    <img src="`+ server_2 + `/static/img/fast-time.svg" class="icon-distance text-center">
                    <p class="text-distance pl-3 text-left">`+ timeConvert(item.sumDuration) + `</p>
                </div>
            </div>
			<div class="col-sm-12 col-smail">
				<div class="d-flex align-items-end">
					<img src="`+ server_2 + `/static/img/bus-stop.svg" class="icon-distance">
					<p class="text-distance pl-3 txt-name-address">` + item.name + `</p>
				</div>
            </div>`
        + (item.type == "go" ? checkPickNumber(item) : "") + `
		</div>`;
}
checkPickNumber = (item) => {
    let pick_up = `<div class="col-sm-6 col-smail border-right-ping mt-3">
        <div class="d-flex justify-content-center">
            <img src="`+ server_2 + `/static/img/user_up.png" class="icon-distance mx-3">
            <p class="text-distance px-0 text-left text-green"> + `+ item.pick_up_number + `</p>
        </div>
    </div>`;
    let drop = `<div class="col-sm-6 col-smail mt-3">
        <div class="d-flex justify-content-center">
            <img src="`+ server_2 + `/static/img/user_down.png" class="icon-distance mx-3">
            <p class="text-distance px-0 text-left text-red"> -  `+ item.drop_number + `</p>
        </div>
    </div>`;
    return pick_up + drop;
}


function btnRunAnimation() {
    resetMovingMarker()
    $("#btnStartCar").html(`<i id="symbutton" class="fa fa-pause"></i>`)
    $("#box-range").removeClass("pointer-event-none");
    isStart = true;
    let listMarker = JSON.parse(sessionStorage.getItem("listMarker"));
    dataAnimate.listMarkerCv = convertArray(listMarker.location_rv);
    dataAnimate.seats = dataTrip.blank_seats;
    document.getElementById("myRange").max = dataAnimate.listMarkerCv.length > 0 ? dataAnimate.listMarkerCv.length - 1 : 20;
    runMovingMarker(dataAnimate.listMarkerCv, 0, dataAnimate.icon, dataAnimate.timeStop, dataAnimate.usersUpDefault, dataAnimate.distance, dataAnimate.duration, dataAnimate.seats)
}


function onChange(e) {
    updateRange(roundUp((e.value / dataAnimate.listMarkerCv.length) * 100, 0))
    $("#btnStartCar").html(`<i id="symbutton" class="fa fa-play"></i>`)
    indexItem = parseInt(e.value);
    resetMovingMarker()
    setMovingMarker(dataAnimate.listMarkerCv, dataAnimate.icon, indexItem)
    isChange = true;
    isStart = false;

}
function updateRange(rangeValue = 0) {
    document.getElementById("rangeValue").innerHTML = rangeValue + "%";
    $('#myRange').css('background', 'linear-gradient(to right, #664AFF 0%, #664AFF ' + rangeValue + '%, #ddd ' + rangeValue + '%, #ddd 100%)');
}

function changeSpeed(t, value) {
    btnStartCar();
    dataAnimate.speed = value * 100;
    myMovingMarker._currentDuration  =  (dataAnimate.listMarkerCv[indexItem][0].duration * 1000) * (100/dataAnimate.speed);
    $(".btn-speed").removeClass("active")
    t.classList.add('active');
    btnStartCar();
}

function btnStartCar(e) {
    if (isStart && !isChange) {
        if (myMovingMarker != "") {
            if (myMovingMarker.isRunning()) {
                myMovingMarker.pause();
                $("#btnStartCar").html(`<i id="symbutton" class="fa fa-play"></i>`)
                isStart = false
            }
        } else {
            $("#btnStartCar").html(`<i id="symbutton" class="fa fa-pause"></i>`)
            continueMovingMarker(indexItem)
            isChange = false;
            isStart = true;
        }
    } else if (isStart && isChange) {
        $("#btnStartCar").html(`<i id="symbutton" class="fa fa-pause"></i>`)
        continueMovingMarker(indexItem)
        isChange = false;
        isStart = true;
    } else if (!isStart) {
        if (myMovingMarker != "") {
            if (!myMovingMarker.isRunning()) {
                myMovingMarker.start();
                $("#btnStartCar").html(`<i id="symbutton" class="fa fa-pause"></i>`)
                isStart = true
            }
        } else {
            $("#btnStartCar").html(`<i id="symbutton" class="fa fa-pause"></i>`)
            continueMovingMarker(indexItem)
            isChange = false;
            isStart = true;
        }
    }
}

