$(function() {
	$('#btnSignUp').click(function(e) {
		e.preventDefault();
		$.ajax({
			url: server_3 + '/signUp',
			data: $('form').serialize(),
			type: 'POST',
			success: function(response) {
				console.log(response);
				// window.location = '/';
			},
			error: function(error) {
				console.log(error);
			}
		});
		// console.log('1');
		// $.getJSON(
		// 	'http://' + server + ':' + port + '/showSignUp',
		// 	{
		// 		// "file": file
		// 	}
		// ).done(function() {
		// 	console.log('Done');
		// });
	});
});
