$(function() {
	$('#btnSignIn').click(function() {
		$.ajax({
			url: server_3+'/validateLogin',
			data: $('form').serialize(),
			type: 'POST',
			success: function(response) {
				console.log(response);
				console.log('Logged');
			},
			error: function(error) {
				console.log(error);
			}
		});
	});
});
