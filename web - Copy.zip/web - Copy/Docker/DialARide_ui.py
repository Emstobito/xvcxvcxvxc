'''
    FMM web application
    Author: Can Yang
'''
from flask import Flask
from flask_cors import CORS
import os
import time
import optparse
import logging
import flask
import requests
from flask import jsonify
from glob import glob
from flask import request
from flask import session
import numpy as np
import json
import urllib3
# from Account import showSignUp
import os
os.system('cls' if os.name == 'nt' else 'clear')
app = flask.Flask(__name__,static_url_path='/static')
CORS(app)
app.config['SEND_FILE_MAX_AGE_DEFAULT'] = 0
app.config['UPLOAD_FOLDER'] = '/static/inputGPS'
app.config['MAX_CONTENT_PATH'] = 1000000
app.config['CORS_HEADERS'] = 'Content-Type'
app.debug = True

@app.route('/layout/header.html')
def header():
    return flask.render_template('layout/header.html')
@app.route('/')
def index():
    print('index')
    return flask.render_template('home.html')
@app.route('/booking.html')
def booking():
    return flask.render_template('booking.html')
@app.route('/vrp.html')
def vrp():
    return flask.render_template('vrp.html')
@app.route('/createdata.html')
def createdata():
    return flask.render_template('createdata.html')



@app.route('/get-list-file')
def get_list_file():
    full_path = os.path.realpath(__file__)
    path_global = os.path.dirname(full_path)
    arr = os.listdir(path_global + "/static/data_didi/total_ride_request")
    return formatApi(arr)
@app.route('/shpfile.html')
def shpfile():
    return flask.render_template('shpfile.html')

def formatApi(data,status=200):
    json = {
        "status": status,
        "data": data
    }
    return jsonify(json)

# ///////////////// Admmin /////////////////////

@app.route('/admin/layout/header.html')
def admin_layout():
    return flask.render_template('/admin/layout/header.html')
@app.route('/admin')
def admin():
    return flask.render_template('/admin/main_management.html')
@app.route('/admin/vehicle-management.html')
def vehicle_management():
    return flask.render_template('/admin/vehicle_management.html')
@app.route('/admin/trip-management.html')
def trip_management():
    return flask.render_template('/admin/trip_management.html')



# ///////////////// Admmin /////////////////////



@app.route('/showSignUp')
def showSignUp():
    return flask.render_template('signup.html')

@app.route('/showSignin')
def showSignin():
    if session.get('user'):
        return flask.render_template('userHome.html')
    else:
        return flask.render_template('signin.html')

@app.route('/userHome')
def userHome():
    if session.get('user'):
        return flask.render_template('userHome.html')
    else:
        return flask.render_template('error.html',error = 'Unauthorized Access')


# @app.route('/logout')
# def logout():
#     session.pop('user',None)
#     return redirect('/')

if __name__ == "__main__":
    app.run(host='0.0.0.0',port=8002)