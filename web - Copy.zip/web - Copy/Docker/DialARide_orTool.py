import json
from ortools.constraint_solver import routing_enums_pb2
from ortools.constraint_solver import pywrapcp
import datetime,time

def print_solution(data, manager, routing, assignment):
    total_distance = 0
    total_load = 0
    result = []
    for vehicle_id in range(data['num_vehicles']):
        index = routing.Start(vehicle_id)
        plan_output = 'Route for vehicle {}:\n'.format(vehicle_id)
        route_distance = 0
        route_load = 0
        arrTrip = [0]
        time_route = 0
        while not routing.IsEnd(index):
            node_index = manager.IndexToNode(index)
            route_load += data['demands'][node_index]
            plan_output += ' {0} Load({1}) -> '.format(node_index, route_load)
            previous_index = index
            index = assignment.Value(routing.NextVar(index))
            route_distance += routing.GetArcCostForVehicle(
                previous_index, index, vehicle_id)
            point = int(format(manager.IndexToNode(index)))
            arrTrip.append(point)
            lenArrTrip = len(arrTrip)
            if (lenArrTrip > 1):
                time_route += data['distance_matrix'][arrTrip[lenArrTrip - 2]][arrTrip[lenArrTrip - 1]]
        plan_output += ' {0} Load({1})\n'.format(manager.IndexToNode(index),
                                                 route_load)
        plan_output += 'Distance of the route: {}m\n'.format(route_distance)
        # plan_output += 'Load of the route: {}\n'.format(route_load)
        plan_output += ('Time of the route: ' + str(time_route) + ' min')
        print('\n')
        print(arrTrip)
        print(plan_output)
        total_distance += route_distance
        total_load += route_load
        result.append(arrTrip)
    print('\n')
    print('Total distance of all routes: {}m'.format(total_distance))
    print('Total load of all routes: {}'.format(total_load))
    return result
def orDistance(dataInput):
    matrix = json.loads(dataInput['matrixDistance'])
    matrix_data = matrix["matrixDistance"]
    n = len(matrix_data)
    m = int((n - 1)/2 + 1)
    z = 20
    pickups_deliveries = []
    for x in range(1,m):
        arr_pD = [2*x-1,2*x]
        pickups_deliveries.append(arr_pD)
    demand = [0]
    for x in range(1, m + 1):
        demand.append(1)
        demand.append(-1)
    capacities = []
    for x in range(1, 2 + 1):
        capacities.append(z)
    data = {}
    data['distance_matrix'] = matrix_data
    data['pickups_deliveries'] = pickups_deliveries
    data['num_vehicles'] = 2
    data['depot'] = 0
    data['demands'] = demand
    data['vehicle_capacities'] = capacities
    
    manager = pywrapcp.RoutingIndexManager(len(data['distance_matrix']),
                                           data['num_vehicles'], data['depot'])

    # Create Routing Model.
    routing = pywrapcp.RoutingModel(manager)

    # Define cost of each arc.
    def distance_callback(from_index, to_index):
        """Returns the manhattan distance between the two nodes."""
        # Convert from routing variable Index to distance matrix NodeIndex.
        from_node = manager.IndexToNode(from_index)
        to_node = manager.IndexToNode(to_index)
        return data['distance_matrix'][from_node][to_node]

    transit_callback_index = routing.RegisterTransitCallback(distance_callback)
    routing.SetArcCostEvaluatorOfAllVehicles(transit_callback_index)

    # Add Capacity constraint.
    def demand_callback(from_index):
        """Returns the demand of the node."""
        # Convert from routing variable Index to demands NodeIndex.
        from_node = manager.IndexToNode(from_index)
        return data['demands'][from_node]

    demand_callback_index = routing.RegisterUnaryTransitCallback(
        demand_callback)
    routing.AddDimensionWithVehicleCapacity(
        demand_callback_index,
        0,  # null capacity slack
        data['vehicle_capacities'],  # vehicle maximum capacities
        True,  # start cumul to zero
        'Capacity')

    # Add Distance constraint.
    dimension_name = 'Distance'
    routing.AddDimension(
        transit_callback_index,
        0,  # no slack
        2000000,  # vehicle maximum travel distance
        True,  # start cumul to zero
        dimension_name)
    distance_dimension = routing.GetDimensionOrDie(dimension_name)
    distance_dimension.SetGlobalSpanCostCoefficient(100)

    for request in data['pickups_deliveries']:
        pickup_index = manager.NodeToIndex(request[0])
        delivery_index = manager.NodeToIndex(request[1])
        routing.AddPickupAndDelivery (pickup_index, delivery_index)
        routing.solver().Add(routing.VehicleVar(pickup_index) == routing.VehicleVar(delivery_index))
        routing.solver().Add(distance_dimension.CumulVar(pickup_index) <= distance_dimension.CumulVar(delivery_index))

    search_parameters = pywrapcp.DefaultRoutingSearchParameters()
    search_parameters.first_solution_strategy = (
        routing_enums_pb2.FirstSolutionStrategy.PARALLEL_CHEAPEST_INSERTION)

    assignment = routing.SolveWithParameters(search_parameters)

    if assignment:
        print('\n')
        result = print_solution(data, manager, routing, assignment)
        print('\n')
    return result