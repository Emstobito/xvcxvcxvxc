### Web Dial A Ride Solver

### Prerequisite 
    - Ubuntu 18.04
    - Docker 20.* (optional)

### Install the environment  
0. IF use proxy 
    - 0.1   `export http_proxy=http://10.77.8.70:8080`
    - 0.2   `export https_proxy=http://10.77.8.70:8080`
    - 0.3   `export no_proxy=127.0.0.1`

1. (Optional) Use Docker
    - 1.1   `docker run -itd -p 8002:8002 -p 8003:8003 -v E:\Panasonic\Ubuntu\:/home/share/ --name DialARide ubuntu:18.04 /bin/bash`
    - 1.2   `docker exec -it DialARide bash`
    - 1.3   `Copy source to path "E:/Panasonic/Ubuntu/" `

2. Install mysql in ubuntu:
    - 2.0 update current system
        - 2.0.1 `apt update`
        - 2.0.2 `apt upgrade`
    - 2.1 `apt install mysql-server -y`
    - 2.2 `/usr/sbin/mysqld --defaults-file=/etc/mysql/my.cnf --basedir=/usr --datadir=/var/lib/mysql --pid-file=/var/run/mysqld/mysqld.pid --socket=/var/run/mysqld/mysqld.sock`
    - 2.3 `/etc/init.d/mysql start`
    - 2.4 `chown -R mysql:mysql /var/lib/mysql `
    - 2.4 `chown -R 0777 /proc/*`
    - 2.5 `mysql_secure_installation` -> set pass: prdcv2021
    - 2.6 `mysql -u root -p` -> (enter)
    - 2.7 `ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY 'prdcv2021';`
    - 2.8 `exit;`
    - 2.9 `mysql -u root -p -> pass: prdcv2021`
    - 2.10 `CREATE DATABASE db_prdcv CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;`
    - 2.11 `use db_prdcv;`
    - 2.12 `source /home/share/web/mysql-db/db_prdcv.sql`
    - 2.13 `exit;`

3. Install python3 in ubuntu:
   
    - 3.1 update current system
        - 3.1.1 `apt update`
        - 3.1.2 `apt upgrade`

    - 3.2 Install python 3.8
        - 3.2.1 `apt install python3.8`
        - 3.2.2 `apt install python3-pip`
        - 3.2.3 (optional) If Command 'python' not found
            - `ln -s /usr/bin/python3.8 /usr/bin/python3 && ln -s /usr/bin/python3 /usr/bin/python`
            -  WARNING: THIS WILL REDICRECT YOUR PYTHON AND PYTHON3 COMMAND TO OTHER BINARY FILES. In other words, 
                from now the python and python3 commands will point to the python3.8 version.
        - 3.2.4 check if python 3.8 was installed correctly
            - `python --version `
            - => Output: Python 3.8.0

4. Import package python:
    - 4.1: install python libraries 
        - `python -m pip install flask flask_cors flask-mysql mysql-connector-python requests ortools routingpy pandas geopy essential_generators datetime`
5. Run python:
    Note: Mở 2 terminal;
    - 5.0 `docker exec -it DialARide bash`
    - 5.1 IF use proxy 
        - 5.1.1 `export http_proxy=http://10.77.8.70:8080`
        - 5.1.2 `export https_proxy=http://10.77.8.70:8080`
        - 5.1.3 `export no_proxy=127.0.0.1`
    - 5.2 `cd home/share/web`
    - 5.3 (terminal 1) `python DialARide_ui.py`
    - 5.4 (terminal 2) `python DialARide_backend.py`
    
### Open website

=> http://localhost:8002/

