# -- proxy_server

proxy_server = True
# proxy_server = False
proxy_server_ip = 'http://10.77.8.70:8080'

# ==================================================

# -- server get matrix distance and time

server_get_matrix = 'online'
# server_get_matrix = 'offline'

# ==================================================

# -- server tile

server_tile = 'online'
# server_tile = 'offline'

# ==================================================

# -- server ip
# server_ip = 'localhost'
server_ip = '10.92.203.62'

# ==================================================

# -- Random booking border
lat_a = 28.5881017
lat_b = 28.489506
lng_a = 77.0251624
lng_b = 77.3182893

# Depot
lat_depot = 28.521234
lng_depot = 77.156789