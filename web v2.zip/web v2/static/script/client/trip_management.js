$(document).ready(function () {
    getListTrips();
});
getListTrips = async () => {
    await $.ajax({
        type: "GET",
        url: server_3 + "/get_all_trip",
        success: function (response) {
            renderRowTrip(response.data.data);
            console.log(response.data.data);
        },
        error: function (e) {
            console.log(e);
        }
    });
}
function renderRowTrip(dataTrips) {
    let html = ``;
    dataTrips.map((item, key) => {
        html = `
            <tr>
                <td>`+(key+1)+`</td>
                <td>Car `+item.car_id+`</td>
                <td class="text-center">`+item.blank_seats+`</td>
                <td><span class="hiddent-text">`+item.name_start_point+`</span></td>
                <td><span class="hiddent-text">`+item.name_stop_point+`</span></td>
                <td>`+item.note+`</td>
                <td>
                    <a href="/admin/vehicle-management.html?trip_id=`+item.id+`" class="list-group-item list-group-item-action">Detail</a>
                </td>
            </tr>
        `
        $("#list-all-trip").append(html);
    })
}
