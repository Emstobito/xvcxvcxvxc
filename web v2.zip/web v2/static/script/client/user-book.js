console.log('config_data:', config_data);
var map = null;
var zoom_level = 10;
var lat = parseFloat(lat_depot);
var lng = parseFloat(lng_depot);
var myMovingMarker = '';
var markerLatOld = '';
var markerLongOld = '';
var markerDurationOld = '';
var markerIcon = '';
var markerCarLast = '';
var myMovingMarkerPolyline = [];
var dataAnimate = {
	timeStop: 2000,
	icon: setIcon(server_2 + '/static/img/car-icon.png', null, [ -0, -10 ]),
	usersUpDefault: 0,
	distance: 0,
	duration: houseToMinute('07:30'),
	seats: 0,
	listMarkerCv: [],
	speed: 10 * 100
};
var indexItem = 0;
var isStart = false;
var isChange = false;

// $(document).ready(function () {
//     loadmaps();
// });
loadmaps = () => {
	var defaultCoord = [ lat, lng ];
	var mapConfig = {
		attributionControl: false,
		center: defaultCoord,
		zoom: zoom_level
	};

	map = L.map('loader', mapConfig);
	if (server_tile == 'online') {
		L.tileLayer('http://{s}.tile.osm.org/{z}/{x}/{y}.png', {
			attribution: '&copy; <a href="http://osm.org/copyright">OpenStreetMap</a> contributors'
		}).addTo(map);
	} else {
		L.tileLayer('http://' + serverIp + ':8080/tile/{z}/{x}/{y}.png', {
			maxZoom: 18,
			attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/">PRDCV</a> contributors',
			id: 'base'
		}).addTo(map);
	}

	// rouTingFc();
};
runMovingMarker = (arMarker, i, icon, timeStop, userInCar, distance, duration, seats) => {
	resetMovingMarker();
	indexItem = i;
	updateRange(roundUp(i / arMarker.length * 100, 0));
	document.getElementById('myRange').value = i;
	let lat = arMarker[i][0].address;
	let long = arMarker[i][1].address;

	markerLatOld = i > 0 ? arMarker[i - 1][0].address : arMarker[i][0].address;
	markerLongOld = i > 0 ? arMarker[i - 1][1].address : arMarker[i][1].address;
	markerDurationOld = i > 0 ? arMarker[i - 1][1].duration * 100 : arMarker[i][1].duration * 100;
	markerIcon = icon;
	myMovingMarker = L.Marker
		.movingMarker([ lat, long ], [ arMarker[i][0].duration * 1000 * (100 / dataAnimate.speed) ], { icon: icon })
		.addTo(map);
	if (i > 0) {
		myMovingMarkerPolyline.push(
			L.polyline([ markerLatOld, markerLongOld ], { color: 'red', weight: 5 }).addTo(map)
		);
	}

	myMovingMarker.start();

	let timeDelay = 0;
	duration = roundUp(duration + arMarker[i][1].duration / 60, 12);
	distance = roundUp(distance + arMarker[i][1].distance, 3);
	if (arMarker[i][1].pick_up_number > 0 || arMarker[i][1].drop_number > 0) {
		timeDelay = timeStop * (arMarker[i][1].pick_up_number + arMarker[i][1].drop_number);
	}

	let speed = roundUp(arMarker[i][1].distance / (arMarker[i][1].duration / 60 / 60), 0);
	$('#speedCar').html(speed ? speed : 0);
	$('#distanceCar').html(distance);
	myMovingMarker.on('end', function(e) {
		let userInCarNew =
			userInCar > 0
				? arMarker[i][1].drop_number > 0
					? userInCar + arMarker[i][1].pick_up_number - arMarker[i][1].drop_number
					: userInCar + arMarker[i][1].pick_up_number
				: arMarker[i][1].pick_up_number;
		let popupMove = popupMoves(userInCarNew, distance, seats, false, arMarker[i][1].sumDuration, speed, timeDelay);
		myMovingMarker.bindPopup(popupMove, {
			closeOnClick: false,
			autoPan: false,
			autoClose: false,
			zoomAnimation: false
		});
		myMovingMarker.openPopup();
		setTimeout(function() {
			if (i + 1 >= arMarker.length) {
				myMovingMarker.closePopup();
				myMovingMarker
					.bindPopup(htmlPopup(userInCarNew, distance, seats, true, duration), {
						autoPan: false,
						autoClose: false
					})
					.openPopup();
				return;
			} else {
				map.removeLayer(myMovingMarker);
				// if (arMarker[i][1].countPeople > 0) {
				// 	let keyIconUser = arMarker[i][1].address.toString();
				// 	let getMarkerUser = markerUser.filter((item, key) => {
				// 		return Object.keys(item)[0] == keyIconUser;
				// 	})
				// 	map.removeLayer(getMarkerUser[0][keyIconUser])
				// }
				this.runMovingMarker(arMarker, i + 1, icon, timeStop, userInCarNew, distance, duration, seats);
			}
		}, timeDelay);
	});
};
continueMovingMarker = (idItem) => {
	console.log('dataAnimate.duration', dataAnimate.duration);
	let userInCar = 0;
	let duration = dataAnimate.duration;
	let distance = 0;
	for (let i = 0; i < idItem; i++) {
		userInCar +=
			dataAnimate.listMarkerCv[i][1].drop_number > 0
				? dataAnimate.listMarkerCv[i][1].pick_up_number - dataAnimate.listMarkerCv[i][1].drop_number
				: dataAnimate.listMarkerCv[i][1].pick_up_number;
		duration += roundUp(dataAnimate.listMarkerCv[i][1].duration / 60, 12);
		distance += roundUp(dataAnimate.listMarkerCv[i][1].distance, 3);
	}
	runMovingMarker(
		dataAnimate.listMarkerCv,
		idItem + 1,
		dataAnimate.icon,
		dataAnimate.timeStop,
		userInCar,
		distance,
		duration,
		dataAnimate.seats
	);
};
var setMvMarker = '';
setMovingMarker = (arMarker, icon, i) => {
	resetMovingMarker(true);
	for (let pl = 0; pl <= i; pl++) {
		plLatOld = pl > 0 ? arMarker[pl - 1][0].address : arMarker[pl][0].address;
		plLongOld = pl > 0 ? arMarker[pl - 1][1].address : arMarker[pl][1].address;
		myMovingMarkerPolyline.push(L.polyline([ plLatOld, plLongOld ], { color: 'red', weight: 5 }).addTo(map));
	}
	let lat = arMarker[i][0].address;
	let long = arMarker[i][1].address;
	setMvMarker = L.Marker.movingMarker([ lat, long ], [ arMarker[i][1].duration * 100 ], { icon: icon }).addTo(map);
};

resetMovingMarker = (isSetMk = false) => {
	if (myMovingMarkerPolyline.length > 0 && isSetMk) {
		myMovingMarkerPolyline.map((item) => {
			map.removeLayer(item);
		});
	}
	if (setMvMarker != '') {
		map.removeLayer(setMvMarker);
		setMvMarker = '';
	}
	if (myMovingMarker != '') {
		map.removeLayer(myMovingMarker);
		myMovingMarker = '';
	}
	if (markerCarLast != '') {
		map.removeLayer(markerCarLast);
		markerCarLast = '';
	}
};

getGeoJson = (coordinates, myStyle) => {
	// console.log("coordinates", coordinates);
	// console.log("myStyle", myStyle);
	// let a = L.polyline(coordinates, { myStyle }).addTo(map);
	// console.log("a", a.toGeoJSON());
	// [[51.507222, -0.1275], [48.8567, 2.3508],
	// [41.9, 12.5], [52.516667, 13.383333], [44.4166,26.1]]
	let cv = convertToGeoJson(coordinates);
	L.geoJson(cv, { style: myStyle }).addTo(map);
};

function timeConvert(n) {
	var num = n;
	var hours = num / 60;
	var rhours = Math.floor(hours) < 10 ? '0' + Math.floor(hours) : Math.floor(hours);
	var minutes = (hours - rhours) * 60;
	var rminutes = roundUp(minutes, 0) < 10 ? '0' + roundUp(minutes, 0) : roundUp(minutes, 0);
	let time =
		rminutes == 60
			? (Math.floor(parseInt(rhours) + 1) < 10
					? '0' + Math.floor(parseInt(rhours) + 1)
					: Math.floor(parseInt(rhours) + 1)) +
				':' +
				'00'
			: rhours + ':' + rminutes;
	return time;
}

function htmlPopup(countUsers, distance, seats, done, sumDuration) {
	return (
		`<div class="set-width"></div>
        <div class="txt-title-popup mb-1">` +
		(done ? 'Success' : 'let go') +
		`</div>
        <div class="row box-info ` +
		(done ? 'justify-content-center' : '') +
		`">
            <div class="col-sm-8 ` +
		(done ? '' : 'offset-md-2') +
		`"col-smail">
                <div class="d-flex justify-content-center">
                    <img src="` +
		server_2 +
		`/static/img/fast-time.svg" class="icon-distance text-center">
                    <p class="text-distance pl-3 text-left my-0">` +
		timeConvert(sumDuration) +
		`</p>
                </div>
            </div>
        </div>
		<div class="box-popup row"> ` +
		mapIconUser(countUsers) +
		`</div>
        <div class="row box-info ` +
		(done ? 'justify-content-center' : '') +
		`">
			<div class="` +
		(done ? 'col-sm-8 col-smail' : 'col-sm-7 col-smail  border-right-ping') +
		` ">
				<div class="d-flex">
					<img src="` +
		server_2 +
		`/static/img/distance.svg" class="icon-distance ` +
		(done ? 'mr-3' : '') +
		`">
					<p class="text-distance">` +
		distance +
		` KM</p>
				</div>
			</div>
			<div class="` +
		(done ? 'd-none' : 'col-sm-5') +
		` col-smail">
				<div class="d-flex">
					<img src="` +
		server_2 +
		`/static/img/school-bus.svg" class="icon-distance">
					<p class="text-distance">` +
		countUsers +
		`/` +
		seats +
		`</p>
				</div>
			</div>
		</div>`
	);
}

function popupMoves(countUsers, distance, seats, done, sumDuration, speed, timeDelay) {
	let html =
		`<div class="set-width"></div>
            <div class="txt-title-popup mb-1"> Run </div>
            <div class="row box-info ` +
		(done ? 'justify-content-center' : '') +
		`">
                <div class="col-sm-8 ` +
		(done ? '' : 'offset-md-2') +
		`"col-smail">
                    <div class="d-flex justify-content-center">
                        <img src="` +
		server_2 +
		`/static/img/fast-time.svg" class="icon-distance text-center">
                        <p class="text-distance pl-3 text-left my-0">` +
		timeConvert(sumDuration) +
		`</p>
                    </div>
                </div>
            </div>
            <div class="row box-info ` +
		(done ? 'justify-content-center' : '') +
		`">
                <div class="` +
		(done ? 'col-sm-8 col-smail' : 'col-sm-7 col-smail  border-right-ping') +
		` ">
                    <div class="d-flex">
                        <img src="` +
		server_2 +
		`/static/img/distance.svg" class="icon-distance ` +
		(done ? 'mr-3' : '') +
		`">
                        <p class="text-distance">` +
		distance +
		` KM</p>
                    </div>
                </div>
                <div class="` +
		(done ? 'd-none' : 'col-sm-5') +
		` col-smail">
                    <div class="d-flex">
                        <img src="` +
		server_2 +
		`/static/img/school-bus.svg" class="icon-distance">
                        <p class="text-distance">` +
		countUsers +
		`/` +
		seats +
		`</p>
                    </div>
                </div>
            </div>`;
	// if(timeDelay == 0) {
	//     html = `<div class="d-flex justify-content-center">
	//             <img src="`+ server_2 + `/static/img/speedometer.svg" class="icon-distance text-center">
	//             <p class="text-distance pl-3 text-left my-0">`+ speed + `KM/H</p>
	//         </div>`;
	// }
	return html;
}

function mapIconUser(length) {
	let html = '';
	let classes = '';
	if (length > 0) {
		if (length == 1) classes = 'col-sm-6 img-one';
		if (length == 2) classes = 'col-sm-6';
		if (length == 3) classes = 'col-sm-4';
		if (length >= 4) classes = 'col-sm-3';
		if (length > 12) classes = 'col-sm-2';
	}
	for (let index = 0; index < length; index++) {
		html +=
			`<div class="item-user ` +
			classes +
			`"><img src="` +
			server_2 +
			`/static/img/user_2.svg" class="icon-car" /></div>`;
	}
	return html;
}

function convertToGeoJson(data) {
	let geoJson = {
		type: 'FeatureCollection',
		features: [
			{
				type: 'Feature',
				properties: {},
				geometry: {
					type: 'LineString',
					coordinates: data
				}
			}
		]
	};
	return geoJson;
}

function setIcon(iconUrl, iconAnchor, popupAnchor) {
	let icAnchor = iconAnchor ? iconAnchor : [ 15, 15 ];
	let puAnchor = popupAnchor ? popupAnchor : [ -0, -25 ];
	return L.icon({
		iconUrl: iconUrl,
		iconSize: [ 30 ],
		iconAnchor: icAnchor,
		popupAnchor: puAnchor,
		className: 'style-icon-car'
	});
}

function convertArray(a) {
	let b = [];
	for (let i = 0; i < a.length; i++) {
		if (i + 1 == a.length) {
			b.push([ a[i], a[i] ]);
		} else {
			b.push([ a[i], a[i + 1] ]);
		}
	}
	return b;
}

function reverseString(st) {
	return st.split(',').reverse().toString();
}

function addMarker(markers, icon) {
	return L.marker(markers, { icon: icon }).addTo(map);
}

function roundUp(num, precision) {
	precision = Math.pow(10, precision);
	return Math.ceil(num * precision) / precision;
}

function houseToMinute(n) {
	return Math.floor(parseInt(n.split(':')[0] * 60) + parseInt(n.split(':')[1]));
}

// test routing offline
rouTingFc = () => {
	let data = JSON.parse(sessionStorage.getItem('dataTrip'));
	let waypoints = [];
	data.list_point.map((item) => {
		waypoints.push(item.address.split(','));
	});
	console.log('waypoints', waypoints);
	let myRouting = L.Routing
		.control({
			waypoints: waypoints,
			show: true,
			routeWhileDragging: false,
			reverseWaypoints: false,
			showAlternatives: false,
			draggable: false,
			lineOptions: {
				styles: [ { color: 'blue', opacity: 0.5, weight: 3, className: 'animate1' } ]
			},
			liveTraffic: true,
			fitSelectedRoutes: 'smart',
			altLineOptions: {
				styles: [
					{ color: 'black', opacity: 0.15, weight: 9 },
					{ color: 'white', opacity: 0.8, weight: 6 },
					{ color: 'blue', opacity: 0.5, weight: 2 }
				]
			},
			createMarker: function(i, waypoint, n) {
				console.log('waypoint.latLng', waypoint.latLng);
				console.log(i);
				console.log(n);
				let icon = setIcon(server_2 + '/static/img/user_2.svg');
				if (i == 0) {
					icon = setIcon(server_2 + '/static/img/placeholder.svg');
				}
				if (i == n - 1) {
					icon = setIcon(server_2 + '/static/img/location.svg');
				}
				const marker = L.marker(waypoint.latLng, {
					draggable: false,
					bounceOnAdd: false,
					bounceOnAddOptions: {
						duration: 1000,
						height: 800,
						function() {
							bindPopup(myPopup).openOn(map);
						}
					},
					icon: icon
				});
				return marker;
			}
		})
		.addTo(map);
	console.log('myRouting', myRouting);
	console.log('_routes', myRouting._routes);
	console.log('getWaypoints', myRouting.getWaypoints());
	console.log('getPlan', myRouting.getPlan());
	console.log('getRouter', myRouting.getRouter());
	console.log('route', myRouting.route());
};

function switchLoading(isLoading) {
	let html = `<div id="loading-page"><div class="spinner"><div></div><div></div></div></div>`;
	$('#loading-page').remove();
	if (isLoading == true) {
		$('body').append(html);
		$('body').addClass('show-loading');
	} else {
		$('#loading-page').remove();
		$('body').removeClass('show-loading');
	}
}
