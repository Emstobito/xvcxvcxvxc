(function($) {
	$('#btnLoadMarker').on('click', function(e) {
		e.preventDefault();
		let markerStart = $('input[name="address_start"]').val().split(',');
		let markerEnd = $('input[name="address_end"]').val().split(',');
		console.log('markerStart', markerStart);
		console.log('markerEnd', markerEnd);
		let icoStart = setIcon(server_2 + '/static/img/placeholder.svg');
		let icoEnd = setIcon(server_2 + '/static/img/location.svg');
		addMarker(markerStart, icoStart);
		addMarker(markerEnd, icoEnd);
		map.setView(markerStart, 15);
		let addressStart = reverseString($('input[name="address_start"]').val());
		let addressEnd = reverseString($('input[name="address_end"]').val());
		let stringData = addressStart + ';' + addressEnd;
		getDistance(stringData);
	});

	$('.button-ico-search').click(function(e) {
		e.preventDefault();
		let value = $(this).parent().find('input').val();
		let result_search = $(this).parent().parent().find('.result-search');
		let parent = $(this).parent();
		let type = $(this).data('type');
		parent.find('input').addClass('diasble');
		parent.find('.loading').addClass('show');
		$.ajax({
			type: 'POST',
			url: server_3 + '/search-maps.html',
			data: { name: value },
			success: function(res) {
				parent.find('input').removeClass('diasble');
				parent.find('.loading').removeClass('show');
				if (res.status == 200) {
					result_search.addClass('show');
					let data = res.data;
					let resultHtml = renderResultItem(data, type);
					result_search.html(resultHtml);
				} else {
					result_search.html(`Error !`);
				}
			}
		});
	});

	clickSetValue = (e) => {
		let data = e.dataset;
		let position = data.position;
		let type = data.type;
		let name = data.name;
		console.log(data);
		if (type == 'start') {
			$('input[name="address_start"]').val(position);
			$('input[name="pickup_point_start"]').val(name);
		}
		if (type == 'end') {
			$('input[name="address_end"]').val(position);
			$('input[name="pickup_point_end"]').val(name);
		}
		if ($('input[name="address_start"]').val() !== '' && $('input[name="address_end"]').val() !== '') {
			let markerStart = $('input[name="address_start"]').val().split(',');
			let markerEnd = $('input[name="address_end"]').val().split(',');
			let icoStart = setIcon(server_2 + '/static/img/placeholder.svg');
			let icoEnd = setIcon(server_2 + '/static/img/location.svg');
			addMarker(markerStart, icoStart);
			addMarker(markerEnd, icoEnd);
			map.setView(markerStart, 15);
			let addressStart = reverseString($('input[name="address_start"]').val());
			let addressEnd = reverseString($('input[name="address_end"]').val());
			let stringData = addressStart + ';' + addressEnd;
			getDistance(stringData, false);
		}
		$('.result-search').removeClass('show');
	};

	renderResultItem = (data, type) => {
		if (data.length == 0) {
			return `<div class="noresults">No Results</div>`;
		}
		let html = ``;
		data.map((item, key) => {
			html +=
				`<div class="result-item highlight" onclick="clickSetValue(this)" data-type="` +
				type +
				`" data-name="` +
				item.display_name +
				`"  data-position="` +
				item.lat +
				`,` +
				item.lon +
				`">`;
			html += `<img class="mapicon" src="` + item.icon + `" alt="icon for boundary administrative">`;
			html += `<span class="name">` + item.display_name + `</span>`;
			html += `<span class="type">(` + item.type + `)</span>`;
			html += `<p class="coords">` + item.lat + `,` + item.lon + `</p>`;
			html += `</div>`;
		});
		return html;
	};
	getDistance = (stringData, isSetData = true) => {
		if (getDistance !== '') {
			console.log('getDistance --> get');
			$.ajax({
				type: 'POST',
				url: server_3 + '/get-distance.html',
				data: { search: stringData },
				success: function(res) {
					console.log('getDistance --> result', res);
					$('#distance').html(`Distance: ` + roundUp(res.data.result.routes[0].distance / 1000, 3) + ` KM`);
					$('#duration').html(
						`Duration: ` + Math.round((res.data.result.routes[0].duration % 3600) / 60) + ' minutes'
					);
					loadDistance(res, isSetData);
				}
			});
		}
	};

	loadDistance = async (res, isSetData) => {
		let listMarker = {
			location: [],
			location_rv: [],
			waypoints: [],
			address: []
		};
		await res.data.result.routes.map((route) => {
			route.legs.map((leg) => {
				leg.steps.map((step) => {
					step.intersections.map((intersection) => {
						listMarker.location.push(intersection.location);
						listMarker.location_rv.push({
							address: intersection.location.slice().reverse(),
							pick_up_number: 0,
							type: 'go',
							name: '',
							duration: step.duration / step.intersections.length,
							distance: step.distance / step.intersections.length / 1000,
							sumDuration: 0
						});
						listMarker.address.push(intersection.location.slice().reverse());
					});
				});
			});
		});
		res.data.result.waypoints.map((item) => listMarker.waypoints.push(item.location.reverse()));
		getGeoJson(listMarker.location, res.data.style);
		if (isSetData) {
			await converAndSetData(listMarker);
		}
	};
	converAndSetData = async (listMarker) => {
		let dataLocation = dataTrip.list_point.map((item, key) => {
			return { ...item, ...{ address: listMarker.waypoints[key] } };
		});
		let mrData = listMarker.location_rv;
		let sumDuration = dataAnimate.duration;
		let sumDurationAr = [];
		await dataLocation.map(async (item, key) => {
			let indexMk = await listMarker.location_rv.findIndex((item2, key2) => {
				sumDuration = roundUp(sumDuration + item2.duration / 60, 12);
				if (item2.address.toString() == item.address.toString()) {
					sumDurationAr.push(sumDuration);
					sumDuration = dataAnimate.duration;

					mrData[key2] = {
						...item,
						...{
							duration: mrData[key2].duration,
							distance: mrData[key2].distance,
							sumDuration: sumDurationAr[key]
						}
					};
				}
				return item2.address.toString() == item.address.toString();
			});
			routerSetMarker(mrData[indexMk]);
		});
		listMarker.location_rv = mrData;
		sessionStorage.setItem('listMarker', JSON.stringify(listMarker));
		switchLoading(false);
		setTimeout(() => {
			btnRunAnimation();
		}, 1500);
	};
	routerSetMarker = (item) => {
		let icoStart = setIcon(server_2 + '/static/img/bus-stop-2.svg', null, [ -0, -15 ]);
		let icoEnd = setIcon(server_2 + '/static/img/location.svg');
		let icoUser = setIcon(server_2 + '/static/img/user_2.svg', [ 15, 30 ]);
		let marker = [];
		switch (item.type) {
			case 'start':
				addMarker(item.address, icoStart).bindPopup(mkPopup(item), { autoPan: false, autoClose: false });
				map.setView(item.address, 14);
				break;
			case 'go':
				addMarker(item.address, icoUser).bindPopup(mkPopup(item), { autoPan: false, autoClose: false });
				break;
			case 'stop':
				addMarker(item.address, icoEnd).bindPopup(mkPopup(item), { autoPan: false, autoClose: false });
				break;
			default:
				break;
		}
	};
	// ---------------------------------------
	$(document).on('click', function(e) {
		let container = $('.box-input-search');
		if (!container.is(e.target) && container.has(e.target).length === 0) {
			container.find('.result-search').removeClass('show');
		}
	});
})(jQuery);
function btnGetPoints() {
	$.ajax({
		url: 'http://' + serverIp + ':8003/get_points',
		type: 'POST',
		success: function(response) {
			console.log(JSON.parse(response));
		},
		error: function() {
			console.log('not done');
		}
	});
}
function btnRunPoint() {
	$.ajax({
		url: server_3 + '/booking',
		data: $('#formUser').serialize(),
		type: 'POST',
		success: function(response) {
			if (response.status == 200) {
				toastr.success(response.data.message);
			}
			setTimeout(function() {
				window.location.reload();
			}, 1000);
		},
		error: function(e) {
			toastr.error('Error !');
		}
	});
}
function btnSwitchForm() {
	if ($('.section-form-fixed').hasClass('show')) {
		$('.section-form-fixed').removeClass('show');
		$('.banner-booking').removeClass('show');
		$('.section-maps').removeClass('map-show');
		map.invalidateSize();
	} else {
		$('.section-form-fixed').addClass('show');
		$('.banner-booking').addClass('show');
		$('.section-maps').addClass('map-show');
		map.invalidateSize();
	}
}
