import csv
import json 
import codecs

def getCsvData(num_orders):
    inputData = []
    with open('statics/file/input.csv','rt')as f:
        data = csv.reader(f)
        for row in data:
            inputData.append(row)
    lenInputData = len(inputData)
    lngIndex = inputData[0].index("longitude")
    latIndex = inputData[0].index("latitude")
    strGetApi = ''
    for x in range(0,num_orders):
        strGetApi = strGetApi + ';' +inputData[x + 1][lngIndex] + ',' + inputData[x + 1][latIndex]
        # print(strGetApi)
    return strGetApi

def getJsonData():
    inputJson = json.load(codecs.open('statics/file/input.json', 'r', 'utf-8-sig')) 

def customSettingDistanceData():
    switcher = {}
    f = open('statics/file/custom_setting_distance.csv','rt')
    data = csv.reader(f)
    i = 0
    for row in data:
        if i > 0:
            row = [ int(x) for x in row ]
            switcher.update({(i - 1):row})
        i += 1
    f.close()
    return switcher

def customSettingTimeData():
    switcher = {}
    f = open('statics/file/custom_setting_time.csv','rt')
    data = csv.reader(f)
    i = 0
    for row in data:
        if i > 0:
            row = [ int(x) for x in row ]
            switcher.update({(i - 1):row})
        i += 1
    f.close()
    return switcher