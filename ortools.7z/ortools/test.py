import pandas as pd
from sklearn import linear_model

tt_thuoc_tinh = {
                'tu_chat': [ 66, 349, 155, 123, 189, 99, 36, 133, 12, 87, 18, 10, 139],
                # 'tcth' : [ 693, 693, 693, 693, 457, 457, 457, 457, 130],
                'level': [ 343, 343, 343, 343, 300, 300, 300, 300, 274, 274, 274, 274, 252],
                # 'buff_dan': [ 554200, 746500, 822700, 514400, 175300, 89700, 138100, 267700],
                # 'buff_hn' : [ 0, 30000, 30000, 0, 33800, 0, 0, 0],
                # 'buff_pt' : [ 11/100, 17.5/100, 15/100, 12/100, 8.5/100, 5.5/100, 2.5/100, 9.5/100],
                'tt_tc': [ 779394, 4121341, 1830395, 1452507, 1708522, 894940, 325432, 1202293, 90537, 656397, 135806, 98082, 887570],
                # 'thuoc_tinh': [ 1480289, 5749713, 3081059, 2202935, 2077747, 1038795, 475121, 139649]
                }

# df = pd.DataFrame(Stock_Market,columns=['tu_chat','tcth','level','buff_dan','buff_hn','buff_pt','tt_tc','thuoc_tinh']) 
df = pd.DataFrame(tt_thuoc_tinh,columns=['tu_chat','level','tt_tc']) 

# X = df[['tu_chat','tcth','level','buff_dan','buff_hn','buff_pt']].astype(float) 
X = df[['tu_chat','level']].astype(float) 
# Y = df['thuoc_tinh'].astype(float)
Y = df['tt_tc'].astype(float)
# Z = df[['tu_chat','tcth','level']].astype(float) 
# W = df['tt_tc'].astype(float)

regr1 = linear_model.LinearRegression()
# regr2 = linear_model.LinearRegression()
# regr1.fit(Z, W)
regr1.fit(X, Y)

tu_chat = 349
# tcth = 130
level = 343
# buff_dan = 22400
# buff_hn = 28800
# buff_pt = 3.5/100
print ('TT tc: \n', regr1.predict([[tu_chat,level]]))
# print ('TT tong: \n', regr2.predict([[tu_chat,tcth,level,buff_dan,buff_hn,buff_pt]]))

print(tu_chat*level*level/10 + level*tu_chat/10)