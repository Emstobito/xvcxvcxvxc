import os
import sys
import csv
import time
import json 
import random
import codecs
import requests
from Or_function import *
from getData import *
from prettytable import PrettyTable
from ortools.constraint_solver import pywrapcp
from ortools.constraint_solver import routing_enums_pb2
from alive_progress import alive_bar,show_bars, show_spinners, showtime

# argparse
def compute(timeOr):
    for i in range(100):
        prc = 0
        if timeOr > 1:
            time.sleep(0.01)  # process items
            prc = 1
        if i == 99:
            time.sleep(timeOr - prc)
        yield  # insert this and you're done!
  
def vrpDistance():
    print("VRP with distances is running... \n")
    getSettingN = getSetting(True)
    if getSettingN == 2:
        number_order = getNumberOrder(True)
        number_vehicles = getNumberVehicles(True)
        capacitie = getCapacities(True)
        max_travel_distance = getMaxTravelDistance(True)
        type_of_data = getTypeOfData(True)
    else:
        custom_setting_data = customSettingDistanceData()
        custom_setting_display = 'Setting demo:\n'
        length_data = len(custom_setting_data)
        table_setting = PrettyTable(['Setting id','Number order','Number vehicles','Vehicle capacities','Max travel distance(m)','Type of data(demo:1,random:2)','Note'])
        for x in range(length_data):
            table_setting.add_row([str(x +1), str(custom_setting_data[x][0]), str(custom_setting_data[x][1]), str(custom_setting_data[x][2]), str(custom_setting_data[x][3]), str(custom_setting_data[x][4]),str(custom_setting_data[x][5])])
            table_setting.add_row(['-----', '-----', '-----', '-----', '-----', '-----', '-----'])
        cleanTerminal()
        print(custom_setting_display)
        print(table_setting)
        get_number_st = input('Enter setting id(1 - ' + str(length_data) + ')\n')
        st = customSetting(int(get_number_st) - 1,'dis')
        number_order = st[0]
        number_vehicles = st[1]
        capacitie = st[2]
        max_travel_distance = st[3]
        type_of_data = st[4]
    if type_of_data == 1:
        name_type_of_data = 'Data Demo'
    else:
        name_type_of_data = 'Data Random'
    cleanTerminal()
    print("Setting: \n - Number order: " 
        + str(number_order) + "\n" 
        + " - Number vehicles: " 
        + str(number_vehicles) + "\n" 
        + " - Vehicle capacities: " 
        + str(capacitie) + "\n" 
        + " - Max travel distance(m): " 
        + str(max_travel_distance) + "\n" 
        + " - Type of data: " 
        + str(name_type_of_data) 
        + "\n")
    strGetApi = getCsvData(number_order)
    depot = [35.0471975,135.7865344]
    strGetApi = str(depot[1]) + ',' + str(depot[0]) + strGetApi
    start_time = time.time()
    matrixApi = get_infoMatrix(strGetApi,start_time)
    # print(matrixApi['distances'])
    print("Or-tools is running...")
    demand = [0,0]
    for x in range(1, number_order + 1):
        demand.append(1)
    capacities = []
    for x in range(1, number_vehicles + 1):
        capacities.append(capacitie)
    start_point = []
    for x in range(1, number_vehicles + 1):
        start_point.append(0)
    end_point = []
    for x in range(1, number_vehicles + 1):
        end_point.append(1)
    data = {}
    data['distance_matrix'] = matrixApi['distances']
    data['num_vehicles'] = number_vehicles
    data['demands'] = demand
    data['vehicle_capacities'] = capacities
    data['starts'] = start_point
    data['ends'] = end_point
    start_or_time = time.time()

    # Create the routing index manager.
    manager = pywrapcp.RoutingIndexManager(len(data['distance_matrix']),
                                           data['num_vehicles'], data['starts'],
                                           data['ends'])

    # Create Routing Model.
    routing = pywrapcp.RoutingModel(manager)

    # Create and register a transit callback.
    def distance_callback(from_index, to_index):
        """Returns the distance between the two nodes."""
        # Convert from routing variable Index to distance matrix NodeIndex.
        from_node = manager.IndexToNode(from_index)
        to_node = manager.IndexToNode(to_index)
        return data['distance_matrix'][from_node][to_node]

    transit_callback_index = routing.RegisterTransitCallback(distance_callback)

    # Define cost of each arc.
    routing.SetArcCostEvaluatorOfAllVehicles(transit_callback_index)

    # Add Distance constraint.
    dimension_name = 'Distance'
    routing.AddDimension(
        transit_callback_index,
        0,  # no slack
        max_travel_distance,  # vehicle maximum travel distance
        True,  # start cumul to zero
        dimension_name)
    distance_dimension = routing.GetDimensionOrDie(dimension_name)
    distance_dimension.SetGlobalSpanCostCoefficient(100)

    # Setting first solution heuristic.
    search_parameters = pywrapcp.DefaultRoutingSearchParameters()
    search_parameters.first_solution_strategy = (
        routing_enums_pb2.FirstSolutionStrategy.PATH_CHEAPEST_ARC)

    # Solve the problem.
    solution = routing.SolveWithParameters(search_parameters)
    solverStatus = routing.status()
    solverStatus = solver_stt(solverStatus)

    timeOr = round((time.time() - start_or_time),2)
    print("Checking...")
    with alive_bar(100) as bar:
        if timeOr > 1:
            tt = 1
        else:
            tt = timeOr
        print('a',tt)
        for i in compute(int(tt)):
            bar()
    print('')
    timeRunningOr = 'Time running OR-tools: ' + str("%s seconds" % timeOr)
    print(timeRunningOr)
    print(solverStatus)

    if solution:
        print('\n')
        result = print_solution(data, manager, routing, solution)
        printResult(result)
        if getSettingN == 2:
            dataSettingSave = str(number_order) + ',' + str(number_vehicles) + ',' + str(capacitie) + ',' + str(max_travel_distance) + ',' + str(type_of_data) + ',0' + '\n'
            save_setting = input("Save setting?(Y/n) \n")
            if str(save_setting) == 'y':
                with open('custom_setting_distance.csv','a') as fd:
                    fd.write(dataSettingSave)
                print('Setting saved!!!')
    # printResult()

def orTimesWindow(dt,number_vehicles,demand,capacities,start_point,end_point,matrixDurations,matrixTime_windows,wait_time,wait_time_f,max_travel_time,workingTime_start,start_or_time):
    print('Wait time bonus:',wait_time)
    print('')
    if wait_time != 0:
        len_mt = len(matrixTime_windows)
        a = matrixTime_windows[len_mt - 1][0] - (wait_time * 60)
        b = matrixTime_windows[len_mt - 1][1] + (wait_time * 60)
        c = (a, b)
        matrixTime_windows.append(c)
        del matrixTime_windows[len_mt - 1]
    data = {}
    data['num_vehicles'] = number_vehicles
    data['demands'] = demand
    data['vehicle_capacities'] = capacities
    data['starts'] = start_point
    data['ends'] = end_point
    data['time_matrix'] = matrixDurations
    # data['distance_matrix'] = e
    data['vehicle_capacities'] = capacities
    data['time_windows'] = matrixTime_windows
    print('matrix-time',matrixTime_windows)

    # Create the routing index manager.
    manager = pywrapcp.RoutingIndexManager(len(data['time_matrix']),
                                           data['num_vehicles'], data['starts'],
                                           data['ends'])

    # Create Routing Model.
    routing = pywrapcp.RoutingModel(manager)

    # Create and register a transit callback.
    def time_callback(from_index, to_index):
        """Returns the travel time between the two nodes."""
        # Convert from routing variable Index to time matrix NodeIndex.
        from_node = manager.IndexToNode(from_index)
        to_node = manager.IndexToNode(to_index)
        return data['time_matrix'][from_node][to_node]

    transit_callback_index = routing.RegisterTransitCallback(time_callback)

    # Define cost of each arc.
    routing.SetArcCostEvaluatorOfAllVehicles(transit_callback_index)

    # Add Time Windows constraint.
    time_or = 'Time'
    routing.AddDimension(
        transit_callback_index,
        wait_time,  # allow waiting time
        max_travel_time,  # maximum time per vehicle
        False,  # Don't force start cumul to zero.
        time_or)
    time_dimension = routing.GetDimensionOrDie(time_or)

    # Instantiate route start and end times to produce feasible times.
    for i in range(data['num_vehicles']):
        routing.AddVariableMinimizedByFinalizer(
            time_dimension.CumulVar(routing.Start(i)))
        routing.AddVariableMinimizedByFinalizer(
            time_dimension.CumulVar(routing.End(i)))

    # Setting first solution heuristic.
    search_parameters = pywrapcp.DefaultRoutingSearchParameters()
    search_parameters.first_solution_strategy = (
        routing_enums_pb2.FirstSolutionStrategy.PATH_CHEAPEST_ARC)
    search_parameters.time_limit.seconds = 1

    # Solve the problem.
    solution = routing.SolveWithParameters(search_parameters)

    solverStatus = routing.status()
    solverStatus = solver_stt(solverStatus)

        print('\n')
        result = print_solution_time(data, manager, routing, solution,workingTime_start,wait_time)
        # print(result)
        print("Checking...")
        timeOr = round((time.time() - start_or_time),2)
        with alive_bar(100) as bar:
            if timeOr > 1:
                tt = 1
            else:
                tt = timeOr
            for i in compute(tt):
                bar()
        timeRunningOr = 'Time running OR-tools: ' + str("%s seconds" % timeOr)
        print(timeRunningOr)
        print('')
        printResult(result)
        #Save setting:
        # if getSettingN == 2:
        #     dataSettingSave = str(number_order) + ',' + str(number_vehicles) + ',' + str(capacitie) + ',' + str(max_travel_distance) + ',' + str(type_of_data) + '\n'
        #     save_setting = input("Save setting?(Y/n) \n")
        #     if str(save_setting) == 'y':
        #         with open('custom_settingT.csv','a') as fd:
        #             fd.write(dataSettingSave)
        #         print('Setting saved!!!')
    elif wait_time < 30:
        print('Trying again!')
        orTimesWindow(dt,number_vehicles,demand,capacities,start_point,end_point,matrixDurations,matrixTime_windows,(int(wait_time) + 10),wait_time_f,max_travel_time,workingTime_start,start_or_time)
    else:
        print("Checking...")
        timeOr = round((time.time() - start_or_time),2)
        with alive_bar(100) as bar:
            if timeOr > 1:
                tt = 1
            else:
                tt = timeOr
            for i in compute(tt):
                bar()
        timeRunningOr = 'Time running OR-tools: ' + str("%s seconds" % timeOr)
        print(timeRunningOr)
        print('')
        print('No result!')
        print('')

def vrpTimesWindow():
    print("VRP with times windows is running... \n")
    getSettingN = getSetting(True)
    if getSettingN == 2:
        number_order = getNumberOrder(True)
        number_vehicles = getNumberVehicles(True)
        capacitie = getCapacities(True)
        max_travel_time = getMaxTimeDistance(True)
        workingTime_start = getWorkingTimeStart(True)
        workingTime_end = getWorkingTimeEnd(True)
        wait_time = getWaitTime(True)
        time_deviation = getDeviationTime(True)
        type_of_data = getTypeOfData(True)
        note = getNote(True)
    else:
        custom_setting_data = customSettingTimeData()
        custom_setting_display = 'Setting demo:\n'
        length_data = len(custom_setting_data)
        table_setting = PrettyTable(['Setting id','Number order','Number vehicles','Vehicle capacities','Max travel time(min)','workingTime_start','workingTime_end','wait_time','time_deviation','Type of data(demo:1,random:2)','Note'])
        for x in range(length_data):
            table_setting.add_row([str(x +1), str(custom_setting_data[x][0]), str(custom_setting_data[x][1]), str(custom_setting_data[x][2]), str(custom_setting_data[x][3]), str(custom_setting_data[x][4]),str(custom_setting_data[x][5]),str(custom_setting_data[x][6]),str(custom_setting_data[x][7]),str(custom_setting_data[x][8]),str(custom_setting_data[x][9])])
            table_setting.add_row(['-----', '-----', '-----', '-----', '-----', '-----', '-----', '-----', '-----', '-----', '-----'])
        cleanTerminal()
        print(custom_setting_display)
        print(table_setting)
        get_number_st = input('Enter setting id(1 - ' + str(length_data) + ')\n')
        st = customSetting(int(get_number_st) - 1,'time')
        cleanTerminal()
        number_order = st[0]
        number_vehicles = st[1]
        capacitie = st[2]
        max_travel_time = st[3]
        workingTime_start = st[4]
        workingTime_end = st[5]
        wait_time = st[6]
        time_deviation = st[7]
        type_of_data = st[8]
        note = st[9]
    if type_of_data == 1:
        name_type_of_data = 'Data Demo'
    else:
        name_type_of_data = 'Data Random'
    cleanTerminal()
    print("Setting: \n - Number order: " 
        + str(number_order) + "\n" 
        + " - Number vehicles: " 
        + str(number_vehicles) + "\n" 
        + " - Vehicle capacities: " 
        + str(capacitie) + "\n" 
        + " - Max travel time(s): " 
        + str(max_travel_time) + "\n"
        + " - workingTime_start: " 
        + str(workingTime_start) + "\n"
        + " - workingTime_end: " 
        + str(workingTime_end) + "\n"
        + " - wait_time: " 
        + str(wait_time) + "\n"
        + " - time_deviation: " 
        + str(time_deviation) + "\n" 
        + " - Type of data: " 
        + str(name_type_of_data) + "\n" 
        + " - Note: " 
        + str(note) + "\n"
        + "\n")
    strGetApi = getCsvData(number_order)
    depot = [35.0471975,135.7865344]
    strGetApi = str(depot[1]) + ',' + str(depot[0]) + strGetApi
    start_time = time.time()
    matrixApi = get_infoMatrix(strGetApi,start_time)
    # create time_window
    workingTime = workingTime_end - workingTime_start
    time_windows = [(0,0),(workingTime * 3600 - (wait_time * 60),workingTime * 3600 + (wait_time * 60))]
    w = matrixApi['durations']
    length_time_windows = len(w)
    earliest_timeOrder = 0
    latest_timeOrder = workingTime * 3600
    for x in range(2,number_order + 1):
        startTimeOrderLimit = int(w[0][x])
        endTimeOrderLimit = int(latest_timeOrder - w[x][2])
        randomStartTimeOrder = int(random.randrange(startTimeOrderLimit, endTimeOrderLimit))
        randomEndTimeOrder = int(randomStartTimeOrder + w[x][2] + (time_deviation * 60))
        time_windows.append((randomStartTimeOrder - (wait_time * 60),randomStartTimeOrder + (wait_time * 60)))
    matrixApi.update({"time_windows":time_windows})
    matrixApi.update({"type_input":'Random'})
    print("Or-tools is running...")
    demand = [0,0]
    for x in range(1, number_order - 1):
        demand.append(0)
    capacities = []
    for x in range(1, number_vehicles + 1):
        capacities.append(capacitie)
    start_point = []
    for x in range(1, number_vehicles + 1):
        start_point.append(0)
    end_point = []
    for x in range(1, number_vehicles + 1):
        end_point.append(1)
    start_or_time = time.time()
    # print(start_or_time)
    dt = {}
    dt['num_vehicles'] = number_vehicles
    dt['demands'] = demand
    dt['vehicle_capacities'] = capacities
    dt['starts'] = start_point
    dt['ends'] = end_point
    dt['time_matrix'] = matrixDurations
    # dt['distance_matrix'] = e
    dt['vehicle_capacities'] = capacities
    dt['time_windows'] = matrixTime_windows
    orTimesWindow(dt,number_vehicles,demand,capacities,start_point,end_point,w,matrixApi['time_windows'],0,wait_time_f,max_travel_time,workingTime_start,start_or_time)

def get_mode_name(mode):
    modeName = {
        1: "VRP with distances",
        2: "VRP with times windows - Not available now",
    }
    return modeName.get(int(mode))

def getMode():
    if str.isdigit(mode):
        if int(mode) <= 2 and int(mode) > 0:
            mode_name = get_mode_name(mode)
            print("Mode",mode,":", mode_name,"\n")
            if int(mode) == 1:
                vrpDistance()
            elif int(mode) == 2:
                vrpTimesWindow()
        else:
            mode_name = "Mode not found \n \n" + "List mode: \n" + "1: VRP with distances. \n" + "2: VRP with times windows - Not available now. \n"
            print(mode, mode_name,"\n")
    elif (str(mode) == '--help' or str(mode) == '-h'):
        print("Syntax: \npython file.py <mode number>(1 ~ 2) \n" + "List mode: \n" + "1: VRP with distances. \n" + "2: VRP with times windows - Not available now. \n")
    else:
        print("Mode not found \n \n" + "List mode: \n" + "1: VRP with distances. \n" + "2: VRP with times windows - Not available now. \n")

cleanTerminal()

if len(sys.argv) == 2:
    mode = sys.argv[1]
    getMode()
else:
    print("Syntax Error!")
    print("python file.py <mode number>(1 ~ 2) \n" + "List mode: \n" + "1: VRP with distances. \n" + "2: VRP with times windows - Not available now.(Coming soon!) \n")
    
