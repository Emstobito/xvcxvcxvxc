import os
import time
import codecs
import requests
from getData import *
from prettytable import PrettyTable

def is_int(val):
    try:
        num = int(val)
    except ValueError:
        return False
    return True

def is_float(val):
    try:
        num = float(val)
    except ValueError:
        return False
    return True

def getSetting(r):
    if r == False:
        print('Type error!Enter a number!')
    number_order = input("Setting demo or setting custom?(int) \n1: Demo setting \n2: Custom setting\n")
    check_input = is_int(number_order)
    return int(number_order) if check_input else getSetting(False)

def customSetting(st,mode):
    st = int(st)
    if mode == 'dis':
        switcher = customSettingDistanceData()
    else:
        switcher = customSettingTimeData()
    return switcher.get(st)

def getNumberOrder(r):
    if r == False:
        print('Type error!Enter a number!')
    number_order = input("Number order?(int) \n")
    check_input = is_int(number_order)
    return int(number_order) if check_input else getNumberOrder(False)

def getNumberVehicles(r):
    if r == False:
        print('Type error!Enter a number!')
    number_vehicles = input("Number vehicles?(int) \n")
    check_input = is_int(number_vehicles)
    return int(number_vehicles) if check_input else getNumberVehicles(False)

def getCapacities(r):
    if r == False:
        print('Type error!Enter a number!')
    capacities = input("Vehicle capacities?(int) \n")
    check_input = is_int(capacities)
    return int(capacities) if check_input else getCapacities(False)

def getMaxTravelDistance(r):
    if r == False:
        print('Type error!Enter a number!')
    max_travel_distance = input("Max travel distance(min)?(int) \n")
    check_input = is_int(max_travel_distance)
    return int(max_travel_distance) if check_input else getMaxTravelDistance(False)

def getWorkingTimeStart(r):
    if r == False:
        print('Type error!Enter a number!')
    workingTime_start = input("WorkingTime Start(24h)?(int) \n")
    check_input = is_int(workingTime_start)
    return int(workingTime_start) if check_input else getWorkingTimeStart(False)

def getWorkingTimeEnd(r):
    if r == False:
        print('Type error!Enter a number!')
    workingTime_end = input("WorkingTime End(24h)?(int) \n")
    check_input = is_int(workingTime_end)
    return int(workingTime_end) if check_input else getWorkingTimeEnd(False)

def getNote(r):
    if r == False:
        print('Type error!Enter a number!')
    note = input("Note?(int) \n")
    check_input = is_int(note)
    return int(note) if check_input else getNote(False)

def getMaxTimeDistance(r):
    if r == False:
        print('Type error!Enter a number!')
    max_travel_time = input("Max time travel(min)?(int) \n")
    check_input = is_int(max_travel_time)
    return int(max_travel_time) if check_input else getMaxTimeDistance(False)

def getWaitTime(r):
    if r == False:
        print('Type error!Enter a number!')
    wait_time = input("Wait time(min)?(int) \n")
    check_input = is_int(wait_time)
    return int(wait_time) if check_input else getWaitTime(False)

def getDeviationTime(r):
    if r == False:
        print('Type error!Enter a number!')
    deviation_time = input("Deviation time(min)?(int) \n")
    check_input = is_int(deviation_time)
    return int(deviation_time) if check_input else getDeviationTime(False)

def getTypeOfData(r):
    if r == False:
        print('Error!Enter a number(int)(Data Demo: 1, Data Random: 2 - Not available now!)!')
    type_of_data = input("Type of data?(Data Demo: 1, Data Random: 2 - Not available now!)(int) \n")
    check_input = is_int(type_of_data)
    return int(type_of_data) if (check_input and (int(type_of_data) == 1 or int(type_of_data) == 2)) else getTypeOfData(False)

def get_infoMatrix(e,start_time):
    data = e
    # urlApi = "http://10.92.203.155/table/v1/driving/" + data + '?annotations=distance,duration'
    # urlApi = "http://router.project-osrm.org/table/v1/driving/" + data + '?annotations=distance,duration'
    urlApi = "http://10.92.200.89:5000/table/v1/driving/" + data + '?annotations=distance,duration'
    # urlApi = "http://localhost:5000/table/v1/driving/" + data + '?annotations=distance,duration'
    # print(urlApi)
    result = requests.get(urlApi, headers={}).json()
    # result = requests.get(urlApi, headers={}).encode('utf-8')
    # print(result)
    print('--------------------')
    print('Time get data API:',"%s seconds" % round((time.time() - start_time),2))
    print('\n')
    return result

def cleanTerminal():
    os.system('cls' if os.name == 'nt' else 'clear')

def solver_stt(status):
    switcher = {
        0: "ROUTING_NOT_SOLVED: Problem not solved yet",
        1: "ROUTING_SUCCESS: Problem solved successfully",
        2: "ROUTING_FAIL: No solution found to the problem",
        3: "OUTING_FAIL_TIMEOUT: Time limit reached before finding a solution",
        4: "ROUTING_NOT_SOLVED: Problem not solved yet"
    }
    return switcher.get(status)

def removePoint(data):



def print_solution(data, manager, routing, solution):
    """Prints solution on console."""
    max_route_distance = 0
    result = [['Vehicle Id', 'Distance', 'Plans']]
    for vehicle_id in range(data['num_vehicles']):
        vehicle_plan = ['Vh-' + str(vehicle_id + 1)]
        index = routing.Start(vehicle_id)
        plan_output = 'Route for vehicle {}:\n'.format(vehicle_id + 1)
        route_distance = 0
        plan = ''
        while not routing.IsEnd(index):
            p = manager.IndexToNode(index)
            if p == 0:
                p_plan = '[P]  ' + str(p) + ' - (' + 'point info' + ' - available in next version)\n'
            elif p < 10:
                p_plan = '=> 0' + str(p) + ' - (' + 'point info' + ' - available in next version)\n'
            else:
                p_plan = '=> ' + str(p) + ' - (' + 'point info' + ' - available in next version)\n'
            plan_output += ' {} -> '.format(manager.IndexToNode(index))
            previous_index = index
            index = solution.Value(routing.NextVar(index))
            route_distance += routing.GetArcCostForVehicle(
                previous_index, index, vehicle_id)
            plan += p_plan
        plan += '[H]  ' + str(manager.IndexToNode(index)) + ' - (' + 'point info' + ' - available in next version)\n'
        # plan += '=> 0 - (' + 'point info' + ' - available in next version)'
        plan_output += '{}\n'.format(manager.IndexToNode(index))
        plan_output += 'Distance of the route: {}m\n'.format(route_distance)
        vehicle_plan.append(str(route_distance) + '(m)')
        vehicle_plan.append(plan)
        result.append(vehicle_plan)
        # print(plan_output)
        max_route_distance = max(route_distance, max_route_distance)
    # print(result)
    # print('Maximum of the route distances: {}m'.format(max_route_distance))
    return result

def print_solution_time(data, manager, routing, solution, wkst, wt):
    """Prints solution on console."""
    time_dimension = routing.GetDimensionOrDie('Time')
    total_time = 0
    result = [['Vehicle Id', 'Time of the route', 'Plans']]
    for vehicle_id in range(data['num_vehicles']):
        vehicle_plan = ['Vh-' + str(vehicle_id + 1)]
        index = routing.Start(vehicle_id)
        plan_output = 'Route for vehicle {}:\n'.format(vehicle_id)
        plan = ''

        while not routing.IsEnd(index):
            p = manager.IndexToNode(index)
            time_var = time_dimension.CumulVar(index)

            # mn = solution.Min(time_var) - wt*60
            # mx = solution.Max(time_var) + wt*60
            # if mn > 3600:
            #     t_hour_min = round((mn - (mn % 3600))/60)
            #     t_hour_max = round((mx - (mx % 3600))/60)
            # else:
            #     t_hour_min = 0
            #     t_hour_max = 0
            # t_min = round((mn % 3600)/60)
            # t_max = round((mx % 3600)/60)

            # h_min = wkst + t_hour_min
            # if h_min < 10:
            #     h_min = '0' + str(h_min)
            # m_min = t_min - wt
            # if m_min < 10:
            #     m_min = '0' + str(m_min)
            # h_max = wkst + t_hour_max
            # if h_max < 10:
            #     h_max = '0' + str(h_max)
            # m_max = t_max + wt
            # if m_max < 10:
            #     m_max = '0' + str(m_max)

            # if p == 0:
            #     p_plan = '[P]  ' + str(p) + ' - (' + str(h_min) + ':' + str(m_min) + ' -> ' + str(h_max) + ':' + str(m_max) + ')\n'
            # elif p < 10:
            #     p_plan = '=> 0' + str(p) + ' - (' + str(h_min) + ':' + str(m_min) + ' -> ' + str(h_max) + ':' + str(m_max) + ')\n'
            # else:
            #     p_plan = '=> ' + str(p) + ' - (' + str(h_min) + ':' + str(m_min) + ' -> ' + str(h_max) + ':' + str(m_max) + ')\n'

            if p == 0:
                p_plan = '[P]  ' + str(p) + ' - (' + str(solution.Min(time_var)) + ' -> ' + str(solution.Max(time_var)) + ')\n'
            elif p < 10:
                p_plan = '=> 0' + str(p) + ' - (' + str(solution.Min(time_var)) + ' -> ' + str(solution.Max(time_var)) + ')\n'
            else:
                p_plan = '=> ' + str(p) + ' - (' + str(solution.Min(time_var)) + ' -> ' + str(solution.Max(time_var)) + ')\n'
            plan_output += '{0} Time({1},{2}) -> '.format(
                manager.IndexToNode(index), solution.Min(time_var),
                solution.Max(time_var))
            index = solution.Value(routing.NextVar(index))
            plan += p_plan
        plan += '[H]  ' + str(manager.IndexToNode(index)) + ' - (' + str(solution.Min(time_var)) + ' -> ' + str(solution.Max(time_var)) + ')\n'
        time_var = time_dimension.CumulVar(index)
        plan_output += '{0} Time({1},{2})\n'.format(manager.IndexToNode(index),
                                                    solution.Min(time_var),
                                                    solution.Max(time_var))
        plan_output += 'Time of the route: {}s\n'.format(
            solution.Min(time_var))
        vehicle_plan.append(str(solution.Min(time_var)) + '(s)')
        vehicle_plan.append(plan)
        result.append(vehicle_plan)
        # print(plan_output)
        total_time += solution.Min(time_var)
    print('Total time of all routes: {}min'.format(total_time))

    return result
    # ============================

    max_route_distance = 0
    result = [['Vehicle Id', 'Distance', 'Plans']]
    for vehicle_id in range(data['num_vehicles']):
        vehicle_plan = ['Vh-' + str(vehicle_id + 1)]
        index = routing.Start(vehicle_id)
        plan_output = 'Route for vehicle {}:\n'.format(vehicle_id + 1)
        route_distance = 0
        plan = ''
        while not routing.IsEnd(index):
            p = manager.IndexToNode(index)
            if p == 0:
                p_plan = '[P]  ' + str(p) + ' - (' + 'point info' + ' - available in next version)\n'
            elif p < 10:
                p_plan = '=> 0' + str(p) + ' - (' + 'point info' + ' - available in next version)\n'
            else:
                p_plan = '=> ' + str(p) + ' - (' + 'point info' + ' - available in next version)\n'
            plan_output += ' {} -> '.format(manager.IndexToNode(index))
            previous_index = index
            index = solution.Value(routing.NextVar(index))
            route_distance += routing.GetArcCostForVehicle(
                previous_index, index, vehicle_id)
            plan += p_plan
        plan += '[H]  ' + str(manager.IndexToNode(index)) + ' - (' + 'point info' + ' - available in next version)\n'
        # plan += '=> 0 - (' + 'point info' + ' - available in next version)'
        plan_output += '{}\n'.format(manager.IndexToNode(index))
        plan_output += 'Distance of the route: {}m\n'.format(route_distance)
        vehicle_plan.append(str(route_distance) + '(m)')
        vehicle_plan.append(plan)
        result.append(vehicle_plan)
        # print(plan_output)
        max_route_distance = max(route_distance, max_route_distance)
    # print(result)
    # print('Maximum of the route distances: {}m'.format(max_route_distance))
    return result

def printResult(result):
    vehicle = len(result) - 1
    t = PrettyTable(result[0])
    for x in range(vehicle):
        t.add_row(result[x + 1])
        t.add_row(['-----', '-----', '-----'])
    print('Morning plan:')
    print(t)

    