import matplotlib.pyplot as plt

plt.plot([0,1,2,3,4], [1,2,3,4,10], 'go-', label='Python')
plt.plot([0,1,2,3,4], [10,4,3,2,1], 'ro-', label='C#')
plt.plot([2.5,2.5,2.5,1.5,0.5], [1,3,5,7,10], 'bo-', label='Java')
plt.title('Vẽ đồ thị trong Python với Matplotlib')
plt.xlabel('X')
plt.ylabel('Y')
plt.legend(loc='best')
plt.show()

fig, (ax1, ax2, ax3) = plt.subplots(1,3, figsize=(10,4), sharey=True, dpi=120)

ax1.plot([0,1,2,3,4], [1,2,3,4,10], 'go-')
ax2.plot([0,1,2,3,4], [10,4,3,2,1], 'ro-')
ax3.plot([2.5,2.5,2.5,1.5,0.5], [1,3,5,7,10], 'bo-')

# Title, X and Y labels, X and Y Lim
ax1.set_title('Python'); 
ax2.set_title('C#')
ax3.set_title('Java')

ax1.set_xlabel('X');  ax2.set_xlabel('X');  ax3.set_xlabel('X'); # x label
ax1.set_ylabel('Y');  ax2.set_ylabel('Y');  ax3.set_ylabel('Y')  # y label
ax1.set_xlim(0, 6) ;  ax2.set_xlim(0, 6) ;  ax3.set_xlim(0, 6)   # x axis limits
ax1.set_ylim(0, 12);  ax2.set_ylim(0, 12);  ax3.set_ylim(0, 12)  # y axis limits

# ax2.yaxis.set_ticks_position('none') 
plt.tight_layout()
plt.show()