import os
import pandas as pd
from sklearn import linear_model

tt_thuoc_tinh = {
                'tu_chat': [8, 8, 8, 8, 8, 169],
                'level': [1, 2, 3, 5, 59, 300],
                'tt_tc': [80, 83, 88, 102, 2910, 1527726],
                }

df = pd.DataFrame(tt_thuoc_tinh,columns=['tu_chat','level','tt_tc']) 

X = df[['tu_chat','level']].astype(float) 
Y = df['tt_tc'].astype(float)

regr1 = linear_model.LinearRegression()
regr1.fit(X, Y)

tu_chat = 8
level = 60
os.system('cls' if os.name == 'nt' else 'clear')
print ('Du doan: ', regr1.predict([[tu_chat,level]]))
print('Cong thuc: ', tu_chat*level*level/10 + level*tu_chat/10)
print('\n')