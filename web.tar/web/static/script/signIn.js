$(function() {
	$('#btnSignIn').click(function() {
		$.ajax({
			url: server_3 + '/validateLogin',
			data: $('form').serialize(),
			type: 'POST',
			success: function(response) {
				console.log(response);
				sessionStorage.setItem('logged', response.logged);
				window.location = '/';
			},
			error: function(error) {
				console.log(error);
			}
		});
	});
});
