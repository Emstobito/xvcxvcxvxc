$(function() {
	$('#btnGetPoints').click(function() {
		$.ajax({
			url: 'http://localhost:8003/get_points',
			type: 'POST',
			success: function(response) {
				console.log(JSON.parse(response));
			},
			error: function() {
				console.log('not done');
			}
		});
	});
});
