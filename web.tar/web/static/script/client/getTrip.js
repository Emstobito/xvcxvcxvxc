$(function() {
	$('#btnGetTrip').click(function() {
		$.ajax({
			url: server_3 + '/get_trip',
			type: 'POST',
			success: function(response) {
				console.log(JSON.parse(response));
				console.log(response);
			},
			error: function() {
				console.log('not done');
			}
		});
	});
});
