$(document).ready(function () {
    console.log("object");
    getApi();
});
var dataTrip = {};
getApi = async () => {
    let result = {}
    await $.ajax({
        type: "POST",
        url: server_3 + "/get_trip",
        success: function (res) {
            result = res.data
        }
    });
    dataTrip = result
    sessionStorage.setItem("dataTrip", JSON.stringify(dataTrip));
    $("#nameCar").html(result.car_id);
    $("#numberSeats").html(result.blank_seats);
    result.list_point.map((item) => {
        switch (item.type) {
            case "start":
                $("#carStart").html(item.name);
                break;
            case "go":
                $("#listPickPoints").append(
                    `<div class="row ml-3">
                        <div class="col-12"><h5>
                            -/: `+ item.name + `
                        </h5></div>
                    </div>`
                );
                break;
            case "stop":
                $("#carEnd").html(item.name);
                break;
            default:
                break;
        }
    })

}
$("#btnLoadRouters").click(function async (e) {
    e.preventDefault();
    let icoStart = setIcon(server_2 + "/static/img/placeholder.svg")
    let icoEnd = setIcon(server_2 + "/static/img/location.svg")
    let icoUser = setIcon(server_2 + "/static/img/old.svg")
    let searchRoute = ""
    let locationLength = dataTrip.list_point.length;
    dataTrip.list_point.map((item, key) => {
        searchRoute += locationLength - 1 != key ? reverseString(item.address) + ";" : reverseString(item.address);
        switch (item.type) {
            case "start":
                addMarker(item.address.split(","), icoStart).bindPopup(mkPopup(item), { closeOnClick: false })
                map.setView(item.address.split(","), 15);
                break;
            case "go":
                addMarker(item.address.split(","), icoUser).bindPopup(mkPopup(item), { closeOnClick: false })
                break;
            case "stop":
                addMarker(item.address.split(","), icoEnd).bindPopup(mkPopup(item), { closeOnClick: false })
                break;
            default:
                break;
        }
    })
    getDistance(searchRoute);
});

mkPopup = (item) => {
    return `
        <div class="txt-title-popup">`+ item.type +`</div>
		<div class="row box-info">
			<div class="col-sm-12 col-smail">
				<div class="d-flex align-items-end">
					<img src="`+ server_2 + `/static/img/delivery.svg" class="icon-distance">
					<p class="text-distance pl-3 txt-name-address">` + item.name + `</p>
				</div>
            </div>` 
            + (item.type == "go" ? checkPickNumber(item) : "") + `
		</div>`;
}
checkPickNumber = (item) => {
    let pick_up = `<div class="col-sm-6 col-smail border-right-ping mt-3">
        <div class="d-flex justify-content-center">
            <img src="`+ server_2 + `/static/img/old.svg" class="icon-distance mx-3">
            <p class="text-distance px-0 text-left"> + `+ item.pick_up_number + `</p>
        </div>
    </div>`;
    let drop = `<div class="col-sm-6 col-smail mt-3">
        <div class="d-flex justify-content-center">
            <img src="`+ server_2 + `/static/img/old.svg" class="icon-distance mx-3">
            <p class="text-distance px-0 text-left"> -  `+ item.drop_number + `</p>
        </div>
    </div>`;
    return  pick_up + drop;
}
// $("#btnRunAnimation").on("click", function () {
    
// });

$("#btnRunAnimation").on("click", function (e) {
    let listMarker = JSON.parse(sessionStorage.getItem("listMarker"));
    console.log(listMarker);
    let dataLocation = dataTrip.list_point.map((item, key) => { 
        return { ...item , ...{ "address": listMarker.waypoints[key]} }
    });
    let mrData = listMarker.location_rv;
    dataLocation.map( (item, key) => {
        let indexMk = listMarker.location_rv.findIndex((item2, key) => {
            return item2.address.toString() == item.address.toString();
        })
        if(indexMk != -1) {
            mrData[indexMk] = {...item, ...{ "duration": mrData[indexMk].duration, "distance": mrData[indexMk].distance }}
        }
    })
    let arMarker = convertArray(mrData);
    let timeStop = 1000;
    let timeRun = arMarker[0][0].duration;
    let myIcon = setIcon(server_2 + "/static/img/car-icon.png");
    let countUsers = 0;
    let distance = 0;
    let seats = dataTrip.blank_seats;
    console.log("arMarker", arMarker);
    runMovingMarker(arMarker, timeRun, myIcon, timeStop, 0, countUsers, distance, seats)
})
