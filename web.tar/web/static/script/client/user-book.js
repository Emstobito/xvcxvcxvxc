var map = null;
var zoom_level = 10;
var listMarker = {
    location: [],
    location_rv: [],
};
var lat = 21.0320721;
var lng = 105.812467;
window.onload = function () {
    this.loadmaps();
}
loadmaps = () => {
    var defaultCoord = [lat, lng];
    var mapConfig = {
        attributionControl: false,
        center: defaultCoord,
        zoom: zoom_level
    };
    map = L.map('loader', mapConfig);
    L.tileLayer('http://{s}.tile.osm.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="http://osm.org/copyright">OpenStreetMap</a> contributors'
    }).addTo(map);
    // rouTingFc();
}
rouTingFc = () => {
    let data = JSON.parse(sessionStorage.getItem("dataTrip"));
    let waypoints = [];
    data.list_point.map((item) => {
        waypoints.push(item.address.split(","))
    })
    console.log("waypoints", waypoints);
    let myRouting = L.Routing.control({
        waypoints: waypoints,
        show: true,
        routeWhileDragging: false,
        reverseWaypoints: false,
        showAlternatives: false,
        draggable: false,
        lineOptions: {
            styles: [{ color: 'blue', opacity: .5, weight: 3, className: 'animate' }]
        },
        liveTraffic: true,
        fitSelectedRoutes: "smart",
        altLineOptions: {
            styles: [
                { color: 'black', opacity: 0.15, weight: 9 },
                { color: 'white', opacity: 0.8, weight: 6 },
                { color: 'blue', opacity: 0.5, weight: 2 }
            ]
        },
        createMarker: function (i, waypoint, n) {
            console.log("waypoint.latLng", waypoint.latLng);
            console.log(i);
            console.log(n);
            let icon = setIcon(server_2 + "/static/img/old.svg");
            if (i == 0) {
                icon = setIcon(server_2 + "/static/img/placeholder.svg")
            }
            if (i == n - 1) {
                icon = setIcon(server_2 + "/static/img/location.svg")
            }
            const marker = L.marker(waypoint.latLng, {
                draggable: false,
                bounceOnAdd: false,
                bounceOnAddOptions: {
                    duration: 1000,
                    height: 800,
                    function() {
                        (bindPopup(myPopup).openOn(map))
                    }
                },
                icon: icon
            });
            return marker;
        }
    }).addTo(map);
    console.log("myRouting", myRouting);
    console.log("_routes", myRouting._routes);
    console.log("getWaypoints", myRouting.getWaypoints());
    console.log("getPlan", myRouting.getPlan());
    console.log("getRouter", myRouting.getRouter());
    console.log("route", myRouting.route());
}
addMarker = (markers, icon) => {
    return L.marker(markers, { icon: icon }).addTo(map);
}
runMovingMarker = (arMarker, timeRun, icon, timeStop, i, countUser, distance, seats) => {
    let lat = arMarker[i][0].address;
    let long = arMarker[i][1].address;
    let myMovingMarker = L.Marker.movingMarker([lat, long], [arMarker[i][1].duration], { icon: icon }).addTo(map);
    myMovingMarker.start();
    let timeDelay = arMarker[i][1].pick_up_number > 0 ? timeStop * arMarker[i][1].pick_up_number : 0;
    distance = roundUp(distance +  arMarker[i][1].distance, 3);
    if(arMarker[i][1].pick_up_number > 0) { map.setView(long, 15) };
    myMovingMarker.on('end', function (e) {
        let countUsers = countUser > 0 ? countUser + arMarker[i][1].pick_up_number - arMarker[i][1].drop_number : arMarker[i][1].pick_up_number;
        console.log("arMarker[i][1].pick_up_number", arMarker[i][1].pick_up_number);
        console.log("arMarker[i][1].drop_number", arMarker[i][1].drop_number);
        // let countUsers = countUser + arMarker[i][1].pick_up_number - arMarker[i][1].drop_number;
        let userPopup = htmlPopup(countUsers, distance, seats);
        myMovingMarker.bindPopup(userPopup, { closeOnClick: false }).openPopup()
        setTimeout(function () {
            map.removeLayer(myMovingMarker)
            if (i + 1 >= arMarker.length) {
                markerCarLast = L.marker(arMarker[i][1].address, { icon: icon }).addTo(map);;
                markerCarLast.bindPopup(htmlPopup(countUsers, distance, seats, true), { closeOnClick: false }).openPopup()
                return
            } else {
                // if (arMarker[i][1].countPeople > 0) {
                // 	let keyIconUser = arMarker[i][1].address.toString();
                // 	let getMarkerUser = markerUser.filter((item, key) => {
                // 		return Object.keys(item)[0] == keyIconUser;
                // 	})
                // 	map.removeLayer(getMarkerUser[0][keyIconUser])
                // }
                this.runMovingMarker(arMarker, arMarker[i][1].duration, icon, timeStop, i + 1, countUsers, distance, seats)
            }
        }, timeDelay)
    });
}
htmlPopup = (countUsers, distance, seats, done) => {
    return `<div class="set-width"></div>
        <div class="txt-title-popup mb-1">`+ (done ? "Success" : "let go") +`</div>
		<div class="box-popup row"> `+ mapIconUser(countUsers) + `</div>
		<div class="row box-info `+ (done ? "justify-content-center" : "") +`">
			<div class="`+ (done ? "col-sm-8 col-smail" : "col-sm-7 col-smail  border-right-ping") +` ">
				<div class="d-flex">
					<img src="`+ server_2 + `/static/img/distance.svg" class="icon-distance `+ (done ? "mr-3" : "") +`">
					<p class="text-distance">` + distance + ` KM</p>
				</div>
			</div>
			<div class="`+ (done ? "d-none" : "col-sm-5") +` col-smail">
				<div class="d-flex">
					<img src="`+ server_2 + `/static/img/school-bus.svg" class="icon-distance">
					<p class="text-distance">`+ countUsers + `/` + seats + `</p>
				</div>
			</div>
		</div>`;
}
mapIconUser = (length) => {
    let html = "";
    let classes = "";
    if (length > 0) {
        if (length == 1) classes = "col-sm-6 img-one";
        if (length == 2) classes = "col-sm-6";
        if (length == 3) classes = "col-sm-4";
        if (length >= 4) classes = "col-sm-3";
        if (length > 12) classes = "col-sm-2";
    }
    for (let index = 0; index < length; index++) {
        html += `<div class="item-user ` + classes + `"><img src="`+server_2+`/static/img/old.svg" class="icon-car" /></div>`
    }
    return html;
}
getGeoJson = (coordinates, myStyle) => {
    console.log("getGeoJson --> coordinates", coordinates);
    let cv = convertToGeoJson(coordinates);
    L.geoJson(cv, { style: myStyle }).addTo(map);
}
convertToGeoJson = (data) => {
    let geoJson = {
        "type": "FeatureCollection",
        "features": [
            {
                "type": "Feature",
                "properties": {},
                "geometry": {
                    "type": "LineString",
                    "coordinates": data
                }
            }
        ]
    };
    return geoJson;
}
setIcon = (iconUrl) => {
    return L.icon({
        iconUrl: iconUrl,
        iconSize: [30],
        iconAnchor: [15, 30],
        popupAnchor: [-2, -22],
        className: "style-icon-car"
    });
}
convertArray = (a) => {
    let b = [];
    a.map((key, item) => {
        if (item + 1 < a.length) {
            b.push([a[item], a[item + 1]]);
        }
    })
    return b;
}
reverseString = (st) => {
    return st.split(",").reverse().toString();
}

// function decimalAdjust(type, value, exp) {
//     // If the exp is undefined or zero...
//     if (typeof exp === 'undefined' || +exp === 0) {
//         return Math[type](value);
//     }
//     value = +value;
//     exp = +exp;
//     // If the value is not a number or the exp is not an integer...
//     if (isNaN(value) || !(typeof exp === 'number' && exp % 1 === 0)) {
//         return NaN;
//     }
//     // Shift
//     value = value.toString().split('e');
//     value = Math[type](+(value[0] + 'e' + (value[1] ? (+value[1] - exp) : -exp)));
//     // Shift back
//     value = value.toString().split('e');
//     return +(value[0] + 'e' + (value[1] ? (+value[1] + exp) : exp));
// }

// if (!Math.ceil10) {
//     Math.ceil10 = function (value, exp) {
//         return decimalAdjust('ceil', value, exp);
//     };
// }


function roundUp(num, precision) {
    precision = Math.pow(10, precision)
    return Math.ceil(num * precision) / precision
  }