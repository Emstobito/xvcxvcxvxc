(function($) {
	var listMarker = {
		location: [],
		location_rv: [],
		waypoints: [],
		address: []
	};

	$('#btnLoadMarker').on('click', function(e) {
		e.preventDefault();
		let markerStart = $('input[name="address_start"]').val().split(',');
		let markerEnd = $('input[name="address_end"]').val().split(',');
		console.log('markerStart', markerStart);
		console.log('markerEnd', markerEnd);
		let icoStart = setIcon(server_2 + '/static/img/placeholder.svg');
		let icoEnd = setIcon(server_2 + '/static/img/location.svg');
		addMarker(markerStart, icoStart);
		addMarker(markerEnd, icoEnd);
		map.setView(markerStart, 15);
		// var myStyle = { "color": "#ff7800", "weight": 5, "opacity": 0.65 };
		// getGeoJson([markerStart.slice().reverse(), markerEnd.slice().reverse()], myStyle)
		let addressStart = reverseString($('input[name="address_start"]').val());
		let addressEnd = reverseString($('input[name="address_end"]').val());
		let stringData = addressStart + ';' + addressEnd;
		getDistance(stringData);
	});

	$('.button-ico-search').click(function(e) {
		e.preventDefault();
		let value = $(this).parent().find('input').val();
		let result_search = $(this).parent().parent().find('.result-search');
		let parent = $(this).parent();
		let type = $(this).data('type');
		parent.find('input').addClass('diasble');
		parent.find('.loading').addClass('show');
		$.ajax({
			type: 'POST',
			url: '/search-maps.html',
			data: { name: value },
			success: function(res) {
				parent.find('input').removeClass('diasble');
				parent.find('.loading').removeClass('show');
				if (res.status == 200) {
					result_search.addClass('show');
					let data = res.data;
					let resultHtml = renderResultItem(data, type);
					result_search.html(resultHtml);
				} else {
					result_search.html(`Error !`);
				}
			}
		});
	});

	clickSetValue = (e) => {
		let data = e.dataset;
		let position = data.position;
		let type = data.type;
		let name = data.name;
		if (type == 'start') {
			$('input[name="address_start"]').val(position);
			$('input[name="pickup_point_start"]').val(name);
		}
		if (type == 'end') {
			$('input[name="address_end"]').val(position);
			$('input[name="pickup_point_end"]').val(name);
		}
		let markerStart = $('input[name="address_start"]').val().split(',');
		let markerEnd = $('input[name="address_end"]').val().split(',');
		let icoStart = setIcon(server_2 + '/static/img/placeholder.svg');
		let icoEnd = setIcon(server_2 + '/static/img/location.svg');
		addMarker(markerStart, icoStart);
		addMarker(markerEnd, icoEnd);
		map.setView(markerStart, 15);
		let addressStart = reverseString($('input[name="address_start"]').val());
		let addressEnd = reverseString($('input[name="address_end"]').val());
		let stringData = addressStart + ';' + addressEnd;
		getDistance(stringData);
		$('.result-search').removeClass('show');
	};

	renderResultItem = (data, type) => {
		if (data.length == 0) {
			return `<div class="noresults">No Results</div>`;
		}
		let html = ``;
		data.map((item, key) => {
			html +=
				`<div class="result-item highlight" onclick="clickSetValue(this)" data-type="` +
				type +
				`" data-name="` +
				item.display_name +
				`"  data-position="` +
				item.lat +
				`,` +
				item.lon +
				`">`;
			html += `<img class="mapicon" src="` + item.icon + `" alt="icon for boundary administrative">`;
			html += `<span class="name">` + item.display_name + `</span>`;
			html += `<span class="type">(` + item.type + `)</span>`;
			html += `<p class="coords">` + item.lat + `,` + item.lon + `</p>`;
			html += `</div>`;
		});
		return html;
	};
	getDistance = (stringData) => {
		if (getDistance !== '') {
			console.log('getDistance --> get');
			$.ajax({
				type: 'POST',
				url: '/get-distance.html',
				data: { search: stringData },
				success: function(res) {
					console.log('getDistance --> result', res);
					$('#distance').html(`Distance: ` + res.data.result.routes[0].distance / 1000 + ` KM`);
					$('#duration').html(
						`Duration: ` + Math.round((res.data.result.routes[0].duration % 3600) / 60) + ' minutes'
					);
					loadDistance(res);
				}
			});
		}
	};

	loadDistance = async (res) => {
		await res.data.result.routes.map((route) => {
			route.legs.map((leg) => {
				leg.steps.map((step) => {
					step.intersections.map((intersection) => {
						listMarker.location.push(intersection.location);
						listMarker.location_rv.push({
							address: intersection.location.slice().reverse(),
							pick_up_number: 0,
							type: 'go',
							name: '',
							duration: ((step.duration / step.intersections.length) % 3600) * 1000,
							distance: step.distance / step.intersections.length / 1000
						});
						listMarker.address.push(intersection.location.slice().reverse());
					});
				});
			});
		});
		res.data.result.waypoints.map((item) => listMarker.waypoints.push(item.location.reverse()));
		getGeoJson(listMarker.location, res.data.style);
		sessionStorage.setItem('listMarker', JSON.stringify(listMarker));
	};

	runAnimation = (data) => {
		console.log('listMarker', listMarker);
	};

	// ---------------------------------------
	$(document).on('click', function(e) {
		let container = $('.box-input-search');
		if (!container.is(e.target) && container.has(e.target).length === 0) {
			container.find('.result-search').removeClass('show');
		}
	});
})(jQuery);
