$(function() {
	$('#btnRunPoint').click(function() {
		$.ajax({
			url: server_3 + '/booking',
			data: $('#formUser').serialize(),
			type: 'POST',
			success: function(response) {
				if(response.status == 200) {
					toastr.success(response.data.message)
				}
			},
			error: function(e) {
				toastr.error("Error !")
			}
		});
	});
});
