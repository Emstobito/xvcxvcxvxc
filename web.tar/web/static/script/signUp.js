$(function() {
	$('#btnSignUp').click(function(e) {
		e.preventDefault();
		$.ajax({
			url: server_3 + '/signUp',
			data: $('form').serialize(),
			type: 'POST',
			success: function(response) {
				console.log(response);
				alert('User created successfully!');
				setTimeout(function() {
					window.location = '/';
				}, 1000);
				sessionStorage.setItem('logged', response.logged);
			},
			error: function(error) {
				console.log(error);
			}
		});
		// console.log('1');
		// $.getJSON(
		// 	'http://' + server + ':' + port + '/showSignUp',
		// 	{
		// 		// "file": file
		// 	}
		// ).done(function() {
		// 	console.log('Done');
		// });
	});
});
