from flask import Flask, render_template, json, jsonify, request,redirect,session
from flaskext.mysql import MySQL
from werkzeug.security import generate_password_hash, check_password_hash
import json

from ortools.constraint_solver import routing_enums_pb2
from ortools.constraint_solver import pywrapcp

mysql = MySQL()
app = Flask(__name__)
app.secret_key = '?? :D ??'

# MySQL configurations
app.config['MYSQL_DATABASE_USER'] = 'root'
app.config['MYSQL_DATABASE_PASSWORD'] = '123'
app.config['MYSQL_DATABASE_DB'] = 'web_demo'
app.config['MYSQL_DATABASE_HOST'] = '172.17.0.1'
mysql.init_app(app)


# @app.route('/')
# def main():
#     return render_template('index.html')


@app.route('/validateLogin',methods=['POST'])
def validateLogin():
    try:
        _username = request.form['inputEmail']
        _password = request.form['inputPassword']
        
        con = mysql.connect()
        cursor = con.cursor()
        cursor.callproc('sp_validateLogin',(_username,))
        data = cursor.fetchall()

        if len(data) > 0:
            if check_password_hash(str(data[0][3]),_password):
                session['user'] = data[0][0]
                json = {
                    'user' : session['user'],
                    'logged' : True
                }
                return jsonify(json);
            else:
                return render_template('error.html',error = 'Wrong Email address or Password.')
        else:
            return render_template('error.html',error = 'Wrong Email address or Password.')

    except Exception as e:
        return render_template('error.html',error = str(e))
    finally:
        cursor.close()
        con.close()

@app.route('/signUp',methods=['POST','GET'])
def signUp():
    try:
        _name = request.form['inputName']
        _email = request.form['inputEmail']
        _password = request.form['inputPassword']
        _phone = request.form['inputPhone']
        _birth = request.form['inputBirth']

        conn = mysql.connect()
        cursor = conn.cursor()

        if _name and _email and _password:
            
            _hashed_password = generate_password_hash(_password)
            cursor.callproc('sp_createUser',(_name,_email,_hashed_password,_phone,_birth))
            data = cursor.fetchall()

            if len(data) is 0:
                conn.commit()
                return json.dumps({'message':'User created successfully !'})
            else:
                return json.dumps({'error':str(data[0])})
            
            cursor.close() 
            conn.close()
        else:
            return json.dumps({'html':'<span>Enter the required fields</span>'})

    except Exception as e:
        return json.dumps({'error':str(e)})
        cursor.close() 
        conn.close()

@app.route('/booking',methods=['POST','GET'])
def booking():
    _id_user = request.form['user_id']
    _name = request.form['nameBooking']
    _phone = request.form['phoneBooking']
    _pickup_point_start = request.form['pickup_point_start']
    _address_start = request.form['address_start']
    _pickup_point_end = request.form['pickup_point_end']
    _address_end = request.form['address_end']
    _chair_type = request.form['chair_type']
    _quantity = request.form['quantity']
    _start_date = request.form['start_date']
    _start_time = request.form['start_time']
    _stop_date = request.form['stop_date']
    _stop_time = request.form['stop_time']

    conn = mysql.connect()
    cursor = conn.cursor()
    cursor.callproc('sp_createBooking',(_id_user,_name,_phone,_pickup_point_start,_address_start,_pickup_point_end,_address_end,_chair_type,_quantity,_start_date,_start_time,_stop_date,_stop_time))
    data = cursor.fetchall()
    if len(data) is 0:
        conn.commit()
        return formatApi({'message':'Booking created successfully !'}, 200)
    else:
        return formatApi({'error':str(data[0])}, 400)
    cursor.close() 
    conn.close()

@app.route('/get_trip',methods=['POST','GET'])
def get_trip():
    _trip_id = 1;
    conn = mysql.connect()
    cursor = conn.cursor()
    cursor.callproc('sp_getTrip',(_trip_id,))
    result = cursor.fetchall()
    trips_data = []
    # print(cursor.execute("select *, MAX(p_pick_up) from point_running where point_running.trip_id = 1 GROUP BY point_running.p_address"))
    for trips in result:
        cursor.callproc('sp_getPoint',(_trip_id,))
        result_p = cursor.fetchall()
        points_data = []
        point_start = {
            'name': trips[4],
            'address': trips[5],
            'pick_up_number': 0,
            'drop_number': 0,
            'type': 'start'
        }
        points_data.append(point_start)
        for points in result_p:
            point_data = {
                    'name': points[0],
                    'address': points[1],
                    'pick_up_number': points[2],
                    'drop_number': trips[3],
                    'type': "go"
                    }
            points_data.append(point_data)
        point_stop = {
            'name': trips[6],
            'address': trips[7],
            'pick_up_number': 0,
            'drop_number': 0,
            'type': 'stop'
        }
        points_data.append(point_stop)
        cursor.callproc('sp_getOrder',(_trip_id,))
        result_order = cursor.fetchall()
        list_orders = []
        for orders in result_order:
            list_orders.append(orders[0])
        trips_data = {
                'id': trips[0],
                'car_id': trips[1],
                'blank_seats': trips[2],
                'seated': trips[3],
                'name_start_point': trips[4],
                'start_point': trips[5],
                'name_stop_point': trips[6],
                'stop_point': trips[7],
                'list_point': points_data}

    return formatApi(trips_data)
@app.route('/get_all_trip',methods=['POST','GET'])
def get_all_trip():
    conn = mysql.connect()
    cursor = conn.cursor()
    all_trip_data = []
    number_trip = 10
    for x in range(10):
        _trip_id = x + 1
        cursor.callproc('sp_getTrip',(_trip_id,))
        result = cursor.fetchall()
        trips_data = []
        # print(cursor.execute("select *, MAX(p_pick_up) from point_running where point_running.trip_id = 1 GROUP BY point_running.p_address"))
        for trips in result:
            cursor.callproc('sp_getPoint',(_trip_id,))
            result_p = cursor.fetchall()
            points_data = []
            point_start = {
                'name': trips[4],
                'address': trips[5],
                'pick_up_number': 0,
                'drop_number': 0,
                'type': 'start'
            }
            points_data.append(point_start)
            for points in result_p:
                point_data = {
                        'name': points[0],
                        'address': points[1],
                        'pick_up_number': points[2],
                        'drop_number': trips[3],
                        'type': "go"
                        }
                points_data.append(point_data)
            point_stop = {
                'name': trips[6],
                'address': trips[7],
                'pick_up_number': 0,
                'drop_number': 0,
                'type': 'stop'
            }
            points_data.append(point_stop)
            cursor.callproc('sp_getOrder',(_trip_id,))
            result_order = cursor.fetchall()
            list_orders = []
            for orders in result_order:
                list_orders.append(orders[0])
            trip_data = {
                    'trip_id': trips[0],
                    'car_id': trips[1],
                    'blank_seats': trips[2],
                    'seated': trips[3],
                    'name_start_point': trips[4],
                    'start_point': trips[5],
                    'name_stop_point': trips[6],
                    'stop_point': trips[7],
                    'list_point': points_data}
            all_trip_data.append(trip_data)
        # all_trip_data.append(trips_data)
    return formatApi(all_trip_data)


@app.route('/get_points',methods=['POST','GET'])
def get_point():
    _trip_id = 1;
        
    return json.dumps(points_data)
def create_data_model():
    data = {}
    data['distance_matrix'] = [
        [
            0, 548, 776, 696, 582, 274, 502, 194, 308, 194, 536, 502, 388, 354,
            468, 776, 662
        ],
        [
            548, 0, 684, 308, 194, 502, 730, 354, 696, 742, 1084, 594, 480, 674,
            1016, 868, 1210
        ],
        [
            776, 684, 0, 992, 878, 502, 274, 810, 468, 742, 400, 1278, 1164,
            1130, 788, 1552, 754
        ],
        [
            696, 308, 992, 0, 114, 650, 878, 502, 844, 890, 1232, 514, 628, 822,
            1164, 560, 1358
        ],
        [
            582, 194, 878, 114, 0, 536, 764, 388, 730, 776, 1118, 400, 514, 708,
            1050, 674, 1244
        ],
        [
            274, 502, 502, 650, 536, 0, 228, 308, 194, 240, 582, 776, 662, 628,
            514, 1050, 708
        ],
        [
            502, 730, 274, 878, 764, 228, 0, 536, 194, 468, 354, 1004, 890, 856,
            514, 1278, 480
        ],
        [
            194, 354, 810, 502, 388, 308, 536, 0, 342, 388, 730, 468, 354, 320,
            662, 742, 856
        ],
        [
            308, 696, 468, 844, 730, 194, 194, 342, 0, 274, 388, 810, 696, 662,
            320, 1084, 514
        ],
        [
            194, 742, 742, 890, 776, 240, 468, 388, 274, 0, 342, 536, 422, 388,
            274, 810, 468
        ],
        [
            536, 1084, 400, 1232, 1118, 582, 354, 730, 388, 342, 0, 878, 764,
            730, 388, 1152, 354
        ],
        [
            502, 594, 1278, 514, 400, 776, 1004, 468, 810, 536, 878, 0, 114,
            308, 650, 274, 844
        ],
        [
            388, 480, 1164, 628, 514, 662, 890, 354, 696, 422, 764, 114, 0, 194,
            536, 388, 730
        ],
        [
            354, 674, 1130, 822, 708, 628, 856, 320, 662, 388, 730, 308, 194, 0,
            342, 422, 536
        ],
        [
            468, 1016, 788, 1164, 1050, 514, 514, 662, 320, 274, 388, 650, 536,
            342, 0, 764, 194
        ],
        [
            776, 868, 1552, 560, 674, 1050, 1278, 742, 1084, 810, 1152, 274,
            388, 422, 764, 0, 798
        ],
        [
            662, 1210, 754, 1358, 1244, 708, 480, 856, 514, 468, 354, 844, 730,
            536, 194, 798, 0
        ],
    ]
    data['num_vehicles'] = 4
    data['depot'] = 0
    return data


def print_solution(data, manager, routing, solution):
    max_route_distance = 0
    for vehicle_id in range(data['num_vehicles']):
        index = routing.Start(vehicle_id)
        plan_output = 'Route for vehicle {}:\n'.format(vehicle_id)
        route_distance = 0
        arrTrip = []
        while not routing.IsEnd(index):
            plan_output += ' {} -> '.format(manager.IndexToNode(index))
            arrTrip.append(format(manager.IndexToNode(index)))
            previous_index = index
            index = solution.Value(routing.NextVar(index))
            route_distance += routing.GetArcCostForVehicle(
                previous_index, index, vehicle_id)
        plan_output += '{}\n'.format(manager.IndexToNode(index))
        plan_output += 'Distance of the route: {}m\n'.format(route_distance)
        print(arrTrip)
        print(plan_output)
        max_route_distance = max(route_distance, max_route_distance)
    print('Maximum of the route distances: {}m'.format(max_route_distance))
@app.route('/avr')
def avr():
    data = create_data_model()
    manager = pywrapcp.RoutingIndexManager(len(data['distance_matrix']),
                                           data['num_vehicles'], data['depot'])
    routing = pywrapcp.RoutingModel(manager)
    def distance_callback(from_index, to_index):
        from_node = manager.IndexToNode(from_index)
        to_node = manager.IndexToNode(to_index)
        return data['distance_matrix'][from_node][to_node]
    transit_callback_index = routing.RegisterTransitCallback(distance_callback)
    routing.SetArcCostEvaluatorOfAllVehicles(transit_callback_index)
    dimension_name = 'Distance'
    routing.AddDimension(
        transit_callback_index,
        0,  # no slack
        3000,  # vehicle maximum travel distance
        True,  # start cumul to zero
        dimension_name)
    distance_dimension = routing.GetDimensionOrDie(dimension_name)
    distance_dimension.SetGlobalSpanCostCoefficient(100)
    search_parameters = pywrapcp.DefaultRoutingSearchParameters()
    search_parameters.first_solution_strategy = (
        routing_enums_pb2.FirstSolutionStrategy.PATH_CHEAPEST_ARC)
    solution = routing.SolveWithParameters(search_parameters)
    if solution:
        print_solution(data, manager, routing, solution)

def formatApi(data,status=200):
    json = {
        "status": status,
        "data": data
    }
    return jsonify(json);
if __name__ == "__main__":
    avr()
    app.run(host='0.0.0.0',port=8003)
